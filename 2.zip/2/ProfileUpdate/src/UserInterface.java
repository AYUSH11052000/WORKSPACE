import java.util.Scanner;
public class UserInterface 
{
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		//Fill code here 
		        
		        System.out.println("Enter your name");
		        String name = sc.nextLine();

		        System.out.println("Enter your PAN number");
		        String panNumber = sc.nextLine();

		        System.out.println("Enter your E-mail ID");
		        String email = sc.nextLine();
 
		        if (panNumber.length() ==10 && panNumber.matches("[A-Z]{5}\\d{4}[A-Z]")) {
		             
		            if (email.matches("[a-z]{5,10}@digitec.com")) {
		                 
		                System.out.println("Profile of " + name + " updated successfully");
		            } else {
		                
		                System.out.println("Invalid E-mail ID");
		            }
		        } else {
		            
		            System.out.println(panNumber + " is an invalid PAN number");
		            return;
		        }

		       
		    
		

	}
}