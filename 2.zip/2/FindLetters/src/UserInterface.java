 import java.util.*;
public class UserInterface{
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		//FILL CODE HERE
		System.out.println("Enter the word");
		String word = sc.nextLine();
		System.out.println("Enter the two indices");
		int d1 = sc.nextInt();
		sc.nextLine();
		if (d1>word.length()-1) {
			System.out.println(d1+" is greater than the word length");
			return;
		}
		int d2 = sc.nextInt();
		sc.nextLine();
		if (d2>word.length()-1) {
			System.out.println(d2+" is greater than the word length");
			return;
		}

		if (d1<d2 && d1>=0 && d2>=0 ) {
			String result = word.substring(d1, d2);
			System.out.println(result);
		}
		else {
			System.out.println("Index2 should be greater than Index1");
		}
	}
}