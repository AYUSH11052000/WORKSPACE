-- Drop tables if they exist
DROP TABLE IF EXISTS transactiondetail;
DROP TABLE IF EXISTS beneficiaries;
DROP TABLE IF EXISTS reward;
DROP TABLE IF EXISTS account;
 
-- Create `account` table
CREATE TABLE account (
    accountNumber BIGSERIAL PRIMARY KEY,
    name VARCHAR(50),
    isactive BOOLEAN,
    city VARCHAR(50),
    country VARCHAR(50),
    balance INT,
    emailaddress VARCHAR(50)
);
 
-- Create `beneficiaries` table
CREATE TABLE beneficiaries (
    ssn BIGSERIAL PRIMARY KEY,
    name VARCHAR(50),
    accountnumber BIGINT NOT NULL,
    CONSTRAINT beneficiaries_ibfk_1 FOREIGN KEY (accountnumber) REFERENCES account (accountNumber)
);
 
-- Create `reward` table
CREATE TABLE reward (
    rewardConfirmationNumber BIGSERIAL PRIMARY KEY,
    rewardAmount INT,
    accountNumber BIGINT,
    CONSTRAINT reward_ibfk_1 FOREIGN KEY (accountNumber) REFERENCES account (accountNumber)
);
 
-- Create `transactiondetail` table
CREATE TABLE transactiondetail (
    transactionId BIGSERIAL PRIMARY KEY,
    accountNumber BIGINT,
    transactionDate DATE,
    amount INT,
    txtype VARCHAR(10),
    CONSTRAINT transactiondetail_ibfk_1 FOREIGN KEY (accountNumber) REFERENCES account (accountNumber)
);
 
-- Insert data into `account` table
INSERT INTO account (name, isactive, city, country, balance, emailaddress) 
VALUES 
('shiva', TRUE, 'Bangalore', 'India', 10000, 'sivaprasad.valluru@gmail.com'),
('Prasad', TRUE, 'Hyderabad', 'India', 20000, 'siva@gmail.com');