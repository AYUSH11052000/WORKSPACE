package com.way2learnonline;

import java.sql.SQLException;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.test.ConfigFileApplicationContextInitializer;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;

import com.way2learnonline.service.BankService;
@Component
@Configuration
public class TestMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ConfigurableApplicationContext context =SpringApplication.run(TestMain.class);
		BankService bankService =context.getBean(BankService.class);
		try {
			bankService.transfer(51L,52L,1000);
		}catch (SQLException e) {
			e.printStackTrace();
		}

	}

}
