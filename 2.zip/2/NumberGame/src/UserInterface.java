import java.util.Scanner;

public class UserInterface{
    
    public static void main(String[] args){
        
       Scanner sc=new Scanner(System.in);
       
        //Fill the code here
                System.out.println("Enter the number of chances");
               int chances = sc.nextInt();
               if (chances < 1 || chances > 5) {
                   System.out.println("Your chance " + chances + " is out of range(1-5)");
                   return; 
               }
               int totalSum = 0;
               System.out.println("Enter the numbers");
              for (int i = 0; i < chances*2/2; ++i) {    
                   int num1 = sc.nextInt();
                   int num2 = sc.nextInt();
                   if (num1 < 0 || num1 > 10) {
                       System.out.println(num1 + " is an invalid number");
                       return;   
                   }
                   if (num2 < 0 || num2 > 10) {
                       System.out.println(num2 + " is an invalid number");
                       return;  
                   }
                   totalSum += num1 + num2;
               }
               if (isPrime(totalSum)) {
                   System.out.println("The sum " + totalSum + " is a prime number. You won the game");
               } else {
                   System.out.println("The sum " + totalSum + " is not a prime number. Better luck next time");
               }
           }
           private static boolean isPrime(int num) {
               if (num <= 1) {
                   return false;   
               }
               for (int i = 2; i * i <= num; i++) {
                   if (num % i == 0) {
                       return false;   
                   }
               }
               return true;
           }
       

       }




