import java.util.List;
import java.util.stream.Collector;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class EarphoneUtil {

	public Stream<Earphone> getEarphonesByBrandName(Stream<Earphone> earphoneStream, String brandName) {
		//Fill the code here 
		return earphoneStream.filter(earphone ->earphone.getBrandName().equalsIgnoreCase(brandName));
	}

	public List<Earphone> getEarphonesWithinPriceRange(Stream<Earphone> earphoneStream, double minimumPrice, double maximumPrice) {
		//Fill the code here
		return earphoneStream.filter(earphone->earphone.getPrice()>=minimumPrice && earphone.getPrice()<=maximumPrice)
		.collect(Collectors.toList());
	
	}
}
