import java.util.HashSet;

public class ClassHouseFormation {

	HashSet<String> studSet=new HashSet<String>();
	
	// Include getters and setters

	public void addName(String details)
	{
		// Write code here
		 String a[]=details.split(":");
			 studSet.add(a[1]);
	}
	
	public HashSet<String> getStudSet() {
		return studSet;
	}

	public void setStudSet(HashSet<String> studSet) {
		this.studSet = studSet;
	}

	public HashSet<String> formTeam()
	{	
		HashSet<String> teamSet = new HashSet<>();
        for (String studentName : studSet) {
		String house = "";
		char firstLetter = studentName.charAt(0);
		if((int)firstLetter >= (int)'A' && (int)firstLetter <= (int)'H' ){
			house = "RED";
		}else if ((int)firstLetter >=(int) 'I' && (int)firstLetter <= (int)'P' ){
			house = "BLUE";			
		}else if ((int)firstLetter >= (int)'Q' && (int)firstLetter <= (int)'Z' ){
			house = "GREEN";	
        }
        teamSet.add(studentName + ":" + house);
        }
		return teamSet;
	}
}


