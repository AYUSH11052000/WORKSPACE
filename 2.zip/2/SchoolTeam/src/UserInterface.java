import java.util.HashSet;
import java.util.Scanner;

public class UserInterface {

	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
        
		System.out.println("Enter the number of students ");
		int students = sc.nextInt();
		if (students <= 0) {
            System.out.println("Invalid input");
            return;
        }
		ClassHouseFormation houseFormation = new ClassHouseFormation();
        System.out.println("Enter the details");
        sc.nextLine();
        for (int i = 0; i < students; i++) {
            String details = sc.nextLine();
            houseFormation.addName(details);
        }
        HashSet<String> teamSet = houseFormation.formTeam();
        for (String teamMember : teamSet) {
            System.out.println(teamMember);
        }
    }
}