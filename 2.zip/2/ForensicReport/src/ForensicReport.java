import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

public class ForensicReport {

	private Map<String,Date> reportMap=new HashMap<String,Date>();

	public Map<String, Date> getReportMap() {
		return reportMap;
	}

	public void setReportMap(Map<String, Date> reportMap) {
		this.reportMap = reportMap;
	}

    public void addReportDetails(String reportingOfficer, Date reportFiledDate) {
		//Fill the code here
    	reportMap.put(reportingOfficer,reportFiledDate);	
	}

	public List<String> getOfficersWhoFiledReportsOnDate(Date reportFiledDate){
       //Fill the code here
		 List<String> officers = new ArrayList<>();
	        for (Map.Entry<String, Date> entry : reportMap.entrySet()) {
	            if (entry.getValue().equals(reportFiledDate)) {
	                officers.add(entry.getKey());
	            }
	        }
	        
	        return officers;
        
        
	}
}
