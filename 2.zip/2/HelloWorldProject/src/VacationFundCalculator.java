import java.util.Scanner;
public class VacationFundCalculator {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter vacation fund target:");
		double vacationfundtarget = sc.nextDouble();
		System.out.println("Enter initial fund :");
		double InitialBalance = sc.nextDouble();
		System.out.println("Enter monthly saving :");
		double monthlyBalance = sc.nextDouble();
		System.out.println("Enter Annual Interest");
		double annualInterestRate = sc.nextDouble();
		//get number of month to reach saving goal 
		double monthlyInterestRate = annualInterestRate/12/100;
		int months = calculateMonthsToReachvacationfundtarget(vacationfundtarget,InitialBalance,monthlyBalance,monthlyInterestRate);
		if (months>(80*12)) {
			System.out.println("The Saving isn't realistic");
		}else {
			System.out.println("It takes" + months + "to reach to the saving Goals");
		
		
	

	}

}
	public static int calculateMonthsToReachvacationfundtarget(double vacationfundtarget, double initialBalance, double monthlyBalance, double monthlyInterestRate) {
		int month =0;
		double currentBalance = initialBalance;
		while(currentBalance<vacationfundtarget) {
			month++;
			double interest = currentBalance * monthlyInterestRate;
			currentBalance = currentBalance + interest +monthlyBalance;
			System.out.printf("Month %d:Curret Saving Balance - %.2f\n",month,currentBalance);
		}
		return month;
	}
}
	
