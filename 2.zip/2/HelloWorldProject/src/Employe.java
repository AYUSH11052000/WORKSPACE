
public class Employe {
	int Empid;
	String name;
	double salary;
	
	public void showEmploye() {
		System.out.println("Empl id" + Empid);
		System.out.println("Emloye name"+ name);
		System.out.println("Salary"+ salary);
		
	}

}
