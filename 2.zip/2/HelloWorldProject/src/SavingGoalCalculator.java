import java.util.Scanner;
public class SavingGoalCalculator {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter Saving Goal");
		double savingGoal = scanner.nextDouble();
		System.out.println("Enter Initial Goal");
		double InitialBalance = scanner.nextDouble();
		System.out.println("Enter monthly deposit");
		double monthlydeposit =scanner.nextDouble();
		System.out.println("Enter Annual Interest");
		double annualInterestRate = scanner.nextDouble();
		//get number of month to reach saving goal 
		double monthlyInterestRate = annualInterestRate/12/100;
		int months =calculateMonthsToReachSavingGoal(savingGoal,InitialBalance,monthlydeposit,monthlyInterestRate);
		if (months>(80*12)) {
			System.out.println("The Saving isn't realistic");
		}else {
			System.out.println("It takes" + months + "to reach to the saving Goals");
		}
		
		

	}
	public static int calculateMonthsToReachSavingGoal(double savingGoal ,double InitialBalance, double monthlydeposit,double monthlyInterestRate) {
		int month =0;
		double currentBalance = InitialBalance;
		while(currentBalance<savingGoal) {
			month++;
			double interest = currentBalance * monthlyInterestRate;
			currentBalance = currentBalance + interest +monthlydeposit;
			System.out.printf("Month %d:Curret Saving Balance - %.2f\n",month,currentBalance);
		}
		return month;
		
	}
		
	}


