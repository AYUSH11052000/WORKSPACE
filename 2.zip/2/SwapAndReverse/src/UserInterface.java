import java.util.Scanner;

public class UserInterface 
{
public static void checkAndReverse(String str) {
		
		Scanner sc=new Scanner(System.in);
		
		if(!str.matches("^[A-Za-z\s]+$")) {System.out.println(str+" is an invalid sentence");return;}
		String[] arr=str.split("\s");
		if(arr.length<=2) {System.out.println("Invalid Length");return;}
		else {
			String temp=arr[0];
			arr[0]=arr[arr.length-1];
			arr[arr.length-1]=temp;
			
			StringBuilder sb=new StringBuilder();
			for(int i=1;i<arr.length-1;i++) {
				sb.append(arr[i]+" ");
			}
			sb.reverse();
			System.out.println(arr[0]+sb+" "+arr[arr.length-1]);
			
		}
	}
	
	public static void main(String args[]) 
	{
	
		Scanner sc =new Scanner(System.in);
		//Fill the code
		System.out.println("Enter the sentence:");
        String str = sc.nextLine();
  
       checkAndReverse(str);
}	
	}

