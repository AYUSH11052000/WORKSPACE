import java.util.Scanner;
public class UserInterface 
{
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		//Fill code here 
		System.out.println("Enter your profile code ");
		String code = sc.nextLine();
		if (code.length()!=8) {
System.out.println(code +"does not have the specified length");
		}
		else if (code.charAt(0)!='#') {
			System.out.println(code +"does not start with a valid special character");
		}
		else if (!code.substring(1, 5).matches("[A-Z]{4}")) {
            System.out.println(code.substring(1, 5) + " is an invalid number for uppercase character");
        }
        else if (!code.substring(5).matches("[0-9]{3}")) {
            System.out.println(code.substring(5) + " is an invalid number for digits");
        } else {
            System.out.println("Game code is valid!");
        }
			
		}
	}
	
