import java.sql.Date;
import java.util.List;
import java.util.Map;

public class AttendanceTracker {
	private Map<String, List<Date>> attendanceMap ;

}
