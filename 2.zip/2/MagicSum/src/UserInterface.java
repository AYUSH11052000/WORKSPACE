import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class UserInterface{
    
    public static void main(String[] args){
        
       Scanner sc=new Scanner(System.in);
               System.out.println("Enter the array size");
               int size = sc.nextInt();
               if (size < 1 || size > 5) {
                   System.out.println(size + " is an invalid array size");
                   return;
               }              
               System.out.println("Enter the numbers");
               int[] numbers = new int[size];
               for (int i = 0; i < size; i++) {
                   numbers[i] = sc.nextInt();
                   if (numbers[i] <= 0 || numbers[i] >= 100) {
                       System.out.println(numbers[i] + " is an invalid input");
                       return;
                   }
               }                
               boolean foundPrimeSum = false;

               for (int number : numbers) {
                   if (isPrime(number)) {
                       List<Integer> primes = getConsecutivePrimesSum(number);
                       if (!primes.isEmpty()) {
                           foundPrimeSum = true;
                           System.out.println("The sum of prime numbers is");
                           for (int prime : primes) {
                               System.out.print(prime + " ");
                           }
                           System.out.println();
                       }
                   }
               }

               if (!foundPrimeSum) {
                   System.out.println("The " + size + " numbers are not sum of prime numbers");
               }               
           }            
           public static boolean isPrime(int num) {
               if (num <= 1) return false;
               for (int i = 2; i <= Math.sqrt(num); i++) {
                   if (num % i == 0) {
                       return false;
                   }
               }
               return true;
           }            
           public static List<Integer> getConsecutivePrimesSum(int target) {
               List<Integer> primes = new ArrayList<>();
               List<Integer> consecutivePrimes = new ArrayList<>();
               int sum = 0;
               int current = 2;               
               while (sum < target) {
                   if (isPrime(current)) {
                       consecutivePrimes.add(current);
                       sum += current;
                       if (sum == target) {
                           primes = new ArrayList<>(consecutivePrimes);
                           return primes;
                       }
                   }
                   current++;
               }

               return primes;   
           }
       }  
