package com.demo;

import javax.sql.DataSource;

import org.apache.commons.dbcp2.BasicDataSource;

import com.demo.dao.AccountRepository;
import com.demo.dao.JDBCAccountImpl;
import com.demo.dao.JDBCRewardRepositoryImpl;
import com.demo.dao.JDBCTransactionRepositoryImpl;
import com.demo.dao.RewardRepository;
import com.demo.dao.TransactionRepository;
import com.demo.services.BankService;
import com.demo.services.BankServiceImpl;
import com.demo.services.EmailService;

public class TestMain {

	public static void main(String[] args) {
		

//		BasicDataSource dataSource=new BasicDataSource();
//		dataSource.setUsername("postgres");
//		dataSource.setUrl("jdbc:postgresql://localhost:5434/Banking");
//		dataSource.setPassword("root");
//		 
//		AccountRepository accountRepository= new JDBCAccountImpl(dataSource);
//		TransactionRepository transactionRepository=new JDBCTransactionRepositoryImpl(dataSource);
//		RewardRepository rewardRepository = new JDBCRewardRepositoryImpl(dataSource);
//		EmailService emailService=new EmailService();
//		
//		BankService bankService = new BankServiceImpl(accountRepository,transactionRepository,emailService);
//		
		//bankService.transfer(51L, 50L, 500);
		

	}

}
