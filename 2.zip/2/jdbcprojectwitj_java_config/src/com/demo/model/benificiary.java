package com.demo.model;

public class benificiary {
    private long beneficiaryId;
    private String name;
    private String relationship;
    private String accountNumber; // Beneficiary's account number
    
    // Constructor
    public benificiary(long beneficiaryId, String name, String relationship, String accountNumber) {
        this.beneficiaryId = beneficiaryId;
        this.name = name;
        this.relationship = relationship;
        this.accountNumber = accountNumber;
    }

    // Getters and Setters
    public long getBeneficiaryId() {
        return beneficiaryId;
    }

    public void setBeneficiaryId(long beneficiaryId) {
        this.beneficiaryId = beneficiaryId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getRelationship() {
        return relationship;
    }

    public void setRelationship(String relationship) {
        this.relationship = relationship;
    }

    public String getAccountNumber() {
        return accountNumber;
    }

    public void setAccountNumber(String accountNumber) {
        this.accountNumber = accountNumber;
    }

    @Override
    public String toString() {
        return "Beneficiary [beneficiaryId=" + beneficiaryId + ", name=" + name + ", relationship=" + relationship
                + ", accountNumber=" + accountNumber + "]";
    }
}
