package com.demo.model;

import java.util.Set;

public class Account {

		private long accountnumber;
		private String name;
		private boolean isactive;
		private Set<benificiary> benificiaries;
		private Address address;
		private int balance;
		private String emailaddress;
		
		public Account(long accountnumber, String name, boolean isactive,
				Address address, int balance, String emailaddress) {
			super();
			this.accountnumber = accountnumber;
			this.name = name;
			this.isactive = isactive;
			this.address = address;
			this.balance = balance;
			this.emailaddress = emailaddress;
		}
		public Account() {
			// TODO Auto-generated constructor stub
		}
		public Address getAddress() {
			return address;
		}
		public void setAddress(Address address) {
			this.address = address;
		}
		public long getAccountnumber() {
			return accountnumber;
		}
		public void setAccountnumber(long accountnumber) {
			this.accountnumber = accountnumber;
		}
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		public boolean isIsactive() {
			return isactive;
		}
		public void setIsactive(boolean isactive) {
			this.isactive = isactive;
		}
		public Set<benificiary> getBenificiaries() {
			return benificiaries;
		}
		public void setBenificiaries(Set<benificiary> benificiaries) {
			this.benificiaries = benificiaries;
		}
		
		
		public int getBalance() {
			return balance;
		}
		public void setBalance(int balance) {
			this.balance = balance;
		}
		public String getEmailaddress() {
			return emailaddress;
		}
		public void setEmailaddress(String emailaddress) {
			this.emailaddress = emailaddress;
		}
		
		@Override
		public String toString() {
		    return "Account [accountnumber=" + accountnumber +
		            ", name=" + name +
		            ", isactive=" + isactive +
		            ", benificiaries=" + benificiaries +
		            ", address=" + address +
		            ", balance=" + balance +
		            ", emailaddress=" + emailaddress + "]";
		}

	
}
