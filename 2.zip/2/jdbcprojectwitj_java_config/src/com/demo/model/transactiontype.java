package com.demo.model;

public enum transactiontype {
    CREDIT,
    DEBIT;
}
