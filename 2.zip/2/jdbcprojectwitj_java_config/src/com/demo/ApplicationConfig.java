package com.demo;

import org.apache.commons.dbcp2.BasicDataSource;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.demo.dao.AccountRepository;
import com.demo.dao.JDBCAccountImpl;
import com.demo.dao.JDBCRewardRepositoryImpl;
import com.demo.dao.JDBCTransactionRepositoryImpl;
import com.demo.dao.RewardRepository;
import com.demo.dao.TransactionRepository;
import com.demo.services.BankService;
import com.demo.services.BankServiceImpl;
import com.demo.services.EmailService;

@Configuration
public class ApplicationConfig {
	
	@Bean
	public BasicDataSource dataSource(){
		
		BasicDataSource dataSource=new BasicDataSource();
		dataSource.setUsername("postgres");
		dataSource.setUrl("jdbc:postgresql://localhost:5434/Banking");
		dataSource.setPassword("root");
		
		return dataSource;
		
	}
	@Bean
	public AccountRepository accountRepository() {
		return new JDBCAccountImpl(dataSource());
		
	}
	@Bean
	public RewardRepository rewardRepository() {
		return new JDBCRewardRepositoryImpl(dataSource());
		
	}
	@Bean
	public TransactionRepository transactionRepository() {
		return new JDBCTransactionRepositoryImpl(dataSource());
		
	}
	@Bean
	public EmailService emailService() {
		return new EmailService();
		
	}
	
	@Bean
	public BankService bankService(){
	   BankServiceImpl bankService=new BankServiceImpl();
	   bankService.setAccountRe(accountRepository());
	   bankService.setEmailService(emailService());
	   bankService.setTransactionRe(transactionRepository());	   
	   return bankService;
		
	}

}
