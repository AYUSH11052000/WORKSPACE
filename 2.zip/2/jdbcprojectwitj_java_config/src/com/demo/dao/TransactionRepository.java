package com.demo.dao;

import java.util.List;

import com.demo.model.TransactionDetail;

public interface TransactionRepository {
		
		public long addTransaction(TransactionDetail transactionDetail);
		
		public List<TransactionDetail> getAllTransactionDetailsByAccountNumber(Long accountNumber);
}
