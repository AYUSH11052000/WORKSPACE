package com.demo.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.dbcp2.BasicDataSource;

import com.demo.model.TransactionDetail;
import com.demo.model.transactiontype;

public class JDBCTransactionRepositoryImpl implements TransactionRepository {

	
	private BasicDataSource dataSource;

	public JDBCTransactionRepositoryImpl() {
		super();
	}


	public JDBCTransactionRepositoryImpl(BasicDataSource dataSource) {
		super();
		this.dataSource = dataSource;
	}


	String sql="";
	//PreparedStatement stm=null;
	ResultSet resultSet=null;
	List<TransactionDetail> transactions=null;
	
	public long addTransaction(TransactionDetail transactionDetail) {
	    String sql = "INSERT INTO transactiondetail (accountnumber, transactiondate, amount, txtype) VALUES (?,?,?,?)";
	    try (Connection conn = dataSource.getConnection();
	         PreparedStatement stm = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

	        stm.setLong(1, transactionDetail.getAccountnumber());
	        stm.setDate(2, new java.sql.Date(transactionDetail.getTransactiondate().getTime()));
	        stm.setInt(3, transactionDetail.getAmount());
	        stm.setString(4, transactionDetail.getTxtype().name());

	        int affectedRows = stm.executeUpdate();
	        if (affectedRows > 0) {
	            try (ResultSet generatedKeys = stm.getGeneratedKeys()) {
	                if (generatedKeys.next()) {
	                    transactionDetail.setTransactionid(generatedKeys.getInt(1)); 
	                }
	            }
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	    return transactionDetail.getTransactionid();
	}


	@Override
	public List<TransactionDetail> getAllTransactionDetailsByAccountNumber(Long accountNumber) {
	    List<TransactionDetail> transactions = new ArrayList<>();
	    String sql = "SELECT * FROM transactiondetail WHERE accountnumber = ?";
	    
	    try (Connection conn = dataSource.getConnection(); 
	         PreparedStatement stm = conn.prepareStatement(sql)) {
	         
	        stm.setLong(1, accountNumber);
	        ResultSet resultSet = stm.executeQuery();

	        while (resultSet.next()) {
	            int transactionId = resultSet.getInt("transactionid");    ////////////
	            long account = resultSet.getLong("accountnumber");
	            Date date = resultSet.getDate("transactiondate");
	            int amount = resultSet.getInt("amount");
	           transactiontype type = transactiontype.valueOf(resultSet.getString("txtype"));
	            
	            transactions.add(new TransactionDetail(transactionId, account, date, amount, type));
	        }

	        if (transactions.isEmpty()) {
	            System.out.println("No transactions found for this account.");
	        }

	    } catch (SQLException e) {
	        System.out.println("Error fetching transactions: " + e.getMessage());
	    }
	    return transactions;
	}

	

}
