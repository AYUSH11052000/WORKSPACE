package com.demo.dao;

import java.util.List;

import com.demo.model.Reward;

public interface RewardRepository {
    void addReward(Reward reward);
    int getTotalRewardAmount(Long accountNumber);
    List<Reward> getAllRewardsForAccount(Long accountNumber);
}
