package com.demo.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.dbcp2.BasicDataSource;

import com.demo.model.Account;
import com.demo.model.Address;

public class JDBCAccountImpl implements AccountRepository {
 
	private BasicDataSource dataSource;

    public JDBCAccountImpl(BasicDataSource dataSource) {
		super();
		this.dataSource = dataSource;
	}

	public JDBCAccountImpl() {
		super();
	}

	@Override
    public Account findAccountByNumber(Long accountNumber) {
        String sql = "SELECT * FROM account WHERE accountnumber=?";
        Account account = null;
        try (Connection conn = dataSource.getConnection();
             PreparedStatement stm = conn.prepareStatement(sql)) {

            stm.setLong(1, accountNumber);
            ResultSet resultSet = stm.executeQuery();

            if (resultSet.next()) {
                int accNo = resultSet.getInt("accountnumber");
                boolean active = resultSet.getBoolean("isActive");
                String name = resultSet.getString("name");
                String city = resultSet.getString("city");
                String country = resultSet.getString("country");
                Address address = new Address(city, country);
                int balance = resultSet.getInt("balance");
                String email = resultSet.getString("emailaddress");

                account = new Account(accNo, name, active, address, balance, email);
            }
            resultSet.close();
        } catch (SQLException e) {
            System.out.println("No such account");
        }

        return account;
    }

    @Override
    public List<Account> findAllAccounts() {
        String sql = "SELECT * FROM account";
        List<Account> accounts = new ArrayList<>();
        try (Connection conn = dataSource.getConnection();
             PreparedStatement stm = conn.prepareStatement(sql)) {

            ResultSet resultSet = stm.executeQuery();
            
            while (resultSet.next()) {
                int accNo = resultSet.getInt("accountnumber");
                boolean active = resultSet.getBoolean("isActive");
                String name = resultSet.getString("name");
                String city = resultSet.getString("city");
                String country = resultSet.getString("country");
                Address address = new Address(city, country);
                int balance = resultSet.getInt("balance");
                String email = resultSet.getString("emailaddress");

                Account account = new Account(accNo, name, active, address, balance, email);
                accounts.add(account);
            }
            resultSet.close();
        } catch (SQLException e) {
            System.out.println("No accounts found");
        }

        return accounts;
    }

    @Override
    public void save(Account account) {
        String sql = "INSERT INTO account VALUES (?,?,?,?,?,?,?)";
        try (Connection conn = dataSource.getConnection();
             PreparedStatement stm = conn.prepareStatement(sql)) {

            stm.setLong(1, account.getAccountnumber());
            stm.setString(2, account.getName());
            stm.setBoolean(3, account.isIsactive());
            stm.setString(4, account.getAddress().getCity());
            stm.setString(5, account.getAddress().getCountry());
            stm.setInt(6, account.getBalance());
            stm.setString(7, account.getEmailaddress());

            int result = stm.executeUpdate();
            if (result > 0) {
                System.out.println("Account inserted");
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    @Override
    public void update(Account account) {
        String sql = "UPDATE account SET name=?, isActive=?, balance=? WHERE accountnumber=?";
        try (Connection conn = dataSource.getConnection();
             PreparedStatement stm = conn.prepareStatement(sql)) {

            stm.setString(1, account.getName());
            stm.setBoolean(2, account.isIsactive());
            stm.setInt(3, account.getBalance());
            stm.setLong(4, account.getAccountnumber());

            int result = stm.executeUpdate();
            if (result > 0) {
                System.out.println("Account updated");
            }
        } catch (SQLException e) {
            System.out.println("Error updating account");
        }
    }

    @Override
    public void delete(Account account) {
        String sql = "DELETE FROM account WHERE accountnumber=?";
        try (Connection conn = dataSource.getConnection();
             PreparedStatement stm = conn.prepareStatement(sql)) {

            stm.setLong(1, account.getAccountnumber());

            int result = stm.executeUpdate();
            if (result > 0) {
                System.out.println("Account deleted");
            }
        } catch (SQLException e) {
            System.out.println("Error deleting account");
        }
    }
}
