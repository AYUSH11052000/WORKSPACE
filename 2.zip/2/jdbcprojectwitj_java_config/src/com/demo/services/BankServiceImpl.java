package com.demo.services;

import java.util.Date;
import java.util.List;

import com.demo.dao.AccountRepository;
import com.demo.dao.TransactionRepository;
import com.demo.model.Account;
import com.demo.model.TransactionDetail;
import com.demo.model.transactiontype;

public class BankServiceImpl implements BankService {

    private AccountRepository accountRe;
    public BankServiceImpl() {
		super();
	}

	public AccountRepository getAccountRe() {
		return accountRe;
	}

	public void setAccountRe(AccountRepository accountRe) {
		this.accountRe = accountRe;
	}

	public TransactionRepository getTransactionRe() {
		return transactionRe;
	}

	public void setTransactionRe(TransactionRepository transactionRe) {
		this.transactionRe = transactionRe;
	}

	public EmailService getEmailService() {
		return emailService;
	}

	public void setEmailService(EmailService emailService) {
		this.emailService = emailService;
	}

	private TransactionRepository transactionRe;
    private EmailService emailService;

    public BankServiceImpl(AccountRepository accountRe, TransactionRepository transactionRe, 
                           EmailService emailService) {
        this.accountRe = accountRe;
        this.transactionRe = transactionRe;
        this.emailService = emailService;
    }

    @Override
    public long transfer(long fromAccount, long toAccount, int amount) {
        Account account1 = accountRe.findAccountByNumber(fromAccount);
        Account account2 = accountRe.findAccountByNumber(toAccount);

        if (account1 == null || account2 == null) {
            return -1;
        }
        if (account1.getBalance() < amount) {
            return -1;
        }

        long nSenderBalance = debit(amount, fromAccount);
        if (nSenderBalance == -1) {
            return -1;
        }

        long nReceiverBalance = credit(amount, toAccount);
        if (nReceiverBalance == -1) {
            rollbackDebit(amount, fromAccount);
            return -1;
        }

//        try {
//            long transactionId = generateTransactionId();
//            TransactionDetail debitTransaction = new TransactionDetail(transactionId, fromAccount, new Date(), amount, transactiontype.DEBIT);
//            transactionRe.addTransaction(debitTransaction);
//        } catch (Exception e) {
//            rollbackDebit(amount, fromAccount);
//            return -1;
//        }
//
//        try {
//            long transactionId = generateTransactionId();
//            TransactionDetail creditTransaction = new TransactionDetail(transactionId, toAccount, new Date(), amount, transactiontype.CREDIT);
//            transactionRe.addTransaction(creditTransaction);
//        } catch (Exception e) {
//            rollbackDebit(amount, fromAccount);
//            return -1;
//        }

        try {
            String senderEmail = account1.getEmailaddress();
            String receiverEmail = account2.getEmailaddress();

            String transferMessage = String.format("Transfer successful: %d has been transferred from your account %d.", amount, fromAccount);
            String receivedMessage = String.format("Transfer received: You have received %d from account %d.", amount, fromAccount);

            emailService.sendMail(senderEmail, "bank@example.com", "",transferMessage);
            emailService.sendMail(receiverEmail, "bank@example.com", "",receivedMessage);
        } catch (Exception e) {
            System.out.println("Failed to send email notifications.");
        }

        return amount;
    }

    private long generateTransactionId() {
        return (long) (Math.random() * Long.MAX_VALUE);
    }

    @Override
    public long debit(int amount, long accountNumber) {
        Account account = accountRe.findAccountByNumber(accountNumber);
        if (account != null && account.getBalance() >= amount) {
     
            account.setBalance(account.getBalance() - amount);
            accountRe.update(account);

            try {
                long transactionId = generateTransactionId();
                TransactionDetail debitTransaction = new TransactionDetail(transactionId, accountNumber, new Date(), amount, transactiontype.DEBIT);
                transactionRe.addTransaction(debitTransaction);

                try {
                    String email = account.getEmailaddress();
                    String message = String.format("Your account has been debited with %d. Your new balance is %d.", amount, account.getBalance());
                    emailService.sendMail(email, "bank@example.com", "Debit Notification", message);
                } catch (Exception e) {
                    System.out.println("Failed to send email notification.");
                }
            } catch (Exception e) {
                return -1;
            }
            return account.getBalance();
        } else {
            return -1;
        }
    }


    @Override
    public long credit(int amount, long accountNumber) {
        Account account = accountRe.findAccountByNumber(accountNumber);
        if (account != null) {
            account.setBalance(account.getBalance() + amount);
            accountRe.update(account);

            try {
                long transactionId = generateTransactionId();
                TransactionDetail creditTransaction = new TransactionDetail(transactionId, accountNumber, new Date(), amount, transactiontype.CREDIT);
                transactionRe.addTransaction(creditTransaction);
            } catch (Exception e) {
                return -1;
            }

            return account.getBalance();
        } else {
            return -1;
        }
    }

    private void rollbackDebit(int amount, long accountNumber) {
        Account account = accountRe.findAccountByNumber(accountNumber);
        if (account != null) {
            account.setBalance(account.getBalance() + amount);
            accountRe.update(account);
        }
    }

    @Override
    public void createNewAccount(Account account) {
        accountRe.save(account);
    }

    @Override
    public void deactivateAccount(long accountNumber) {
        Account account = accountRe.findAccountByNumber(accountNumber);
        if (account != null) {
            account.setIsactive(false);
            accountRe.update(account);
        }
    }

    @Override
    public void activateAccount(long accountNumber) {
        Account account = accountRe.findAccountByNumber(accountNumber);
        if (account != null) {
            account.setIsactive(true);
            accountRe.update(account);
        }
    }

    @Override
    public List<Account> getAllAccounts() {
        return accountRe.findAllAccounts();
    }
}
