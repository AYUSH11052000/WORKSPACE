public class EntryUtility {
    public static boolean validateEmployeeId(String employeeId) throws InvalidEntryException {
        //Fill the code here
    	if(employeeId.matches("^GOAIR\\/\\d{4}$")) {
    		return true;
    	}
	    throw new InvalidEntryException("Invalid entry details");
    }
    
    public static boolean validateDuration(int duration) throws InvalidEntryException {
        //Fill the code here
    	if(duration>1 && duration<5) {
	    return true;
    }
    throw new InvalidEntryException("Invalid entry details");
}
}