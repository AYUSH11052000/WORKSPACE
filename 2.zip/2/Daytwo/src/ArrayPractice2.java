import java.io.*;
import java.util.Arrays;

public class ArrayPractice2 {
	 

	public static void main(String[] args) {
		 
		// TODO Auto-generated method stub
		/*int a[]=new int[5];  
		a[0]=10; 
		a[1]=20;  
		a[2]=70;  
		a[3]=40;  
		a[4]=50;  
		for(int i=0;i<a.length;i++)
		System.out.println(a[i]);  */
		////////////////////////
		/*int[] numArray = { 23, -34, 50, 33, 55, 43, 5, -66 };
        int largest = numArray[0];

        for (int num: numArray) {
            if(largest < num)
                largest = num;
        }

        System.out.println(largest);*/
		int[]array = new int[]{90, 23, 5, 109, 12, 22, 67, 34};
		Arrays.sort(array);     
		   
		for (int i = 0; i < array.length-1; i++)   
		{       
		System.out.println(array[i]);   
		



        
		} 

	}
}

	
	
