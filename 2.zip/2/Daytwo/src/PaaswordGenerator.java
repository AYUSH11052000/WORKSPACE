import java.util.Scanner;

public class PaaswordGenerator {

	public static void main(String[] args) {

		 
		        Scanner scanner = new Scanner(System.in);
		        
		        // Step 1: Input Username
		        System.out.print("Enter your username: ");
		        String username = scanner.nextLine();
		        
		        // Step 2: Username Validation
		        if (username.length() != 8) {
		            System.out.println(username + " is an invalid username");
		            return;  // Terminate the application
		        }
		        
		        String firstFour = username.substring(0, 4);
		        char fifthChar = username.charAt(4);
		        String courseIdStr = username.substring(5);
		        
		        // Check the first 4 characters
		        if (!firstFour.matches("[A-Z]{4}")) {
		            System.out.println(username + " is an invalid username");
		            return;  // Terminate the application
		        }
		        
		        // Check if the fifth character is '@'
		        if (fifthChar != '@') {
		            System.out.println(username + " is an invalid username");
		            return;  // Terminate the application
		        }
		        
		        // Check if the last 3 characters represent a valid course ID
		        int courseId;
		        try {
		            courseId = Integer.parseInt(courseIdStr);
		        } catch (NumberFormatException e) {
		            System.out.println(username + " is an invalid username");
		            return;  // Terminate the application
		        }
		        
		        if (courseId < 101 || courseId > 115) {
		            System.out.println(username + " is an invalid username");
		            return;  // Terminate the application
		        }
		        
		        // Step 3: Password Generation
		        // Convert the first 4 letters to lowercase and calculate the sum of ASCII values
		        int asciiSum = 0;
		        for (int i = 0; i < 4; i++) {
		            asciiSum += Character.toLowerCase(firstFour.charAt(i));
		        }
		        
		        // Extract the last 2 digits of the course id
		        String courseIdLastTwo = courseIdStr.substring(1);  // Get last 2 digits
		        
		        // Construct the password
		        String password = "TECH_" + asciiSum + courseIdLastTwo;
		        
		        // Print the generated password
		        System.out.println("Generated Password: " + password);
		    }
		}



