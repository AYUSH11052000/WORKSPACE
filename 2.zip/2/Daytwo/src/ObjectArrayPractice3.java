import java.util.Scanner;

public class ObjectArrayPractice3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		  student[] students = new  student[3];
          Scanner scanner = new Scanner(System.in);        

          for(int i=0; i<students.length; i++)

                        students[i] = new student();
          for(int i=0; i<students.length; i++) {   

                        System.out.println("\nEnter values for Student #No: " + i+1);                      
                        //Get User input for roll no. names and marks

                        System.out.println("Enter RollNo :");

                        students[i].setRollNo(scanner.nextInt());                                              

                        System.out.println("Enter Name :");

                        students[i].setName(scanner.next());                       

                        double[] marks = students[i].getMarks();                       

                        System.out.println("Enter Marks for 3 Subjects :");

                        for(int j =0; j<students[i].getMarks().length; j++) {                                      

                                       marks[j] = scanner.nextDouble();                             
                        }                       

                        students[i].setMark(marks);
          }         

          System.out.println("\n-------");
          for(int i=0; i<students.length; i++) {                       

                        System.out.print("\n Roll No: " + students[i].getRollNo());

                        System.out.print("\t Name: " + students[i].getName());

                        System.out.println("\t Marks: " );

                        for( double mark : students[i].getMarks()) {

                                       System.out.print(mark + " ");
		}		

	}
}}

	
