
public abstract class User {
protected String UserId;
protected String password;
protected UserType userType;
public User() {
	
}
public User(String userId,String password, UserType userType) {
	this.UserId= userId;
	this.password= password;
	this.userType =userType;
}
public String getUserId() {
	return UserId;
}
public void setUserId(String userId) {
	UserId = userId;
}
public String getPassword() {
	return password;
}
public void setPassword(String password) {
	this.password = password;
}
public UserType getUserType() {
	return userType;
}
public void setUserType(UserType userType) {
	this.userType = userType;
}


}
