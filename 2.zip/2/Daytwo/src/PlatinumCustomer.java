
public class PlatinumCustomer extends Customer {

	@Override
	public double CalculateDiscountRate(double orderTotal, double orderQuantity) {
		// TODO Auto-generated method stub
		double baseDiscount = 0.12;
		double additionalDiscount = 0.03;
		if (orderTotal>70000.0) {
			baseDiscount +=baseDiscount +0.01;
		}
		if (orderQuantity>5)
			baseDiscount +=additionalDiscount;
		return baseDiscount;
	}

}
