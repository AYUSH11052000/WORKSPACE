class Bankutility{
	static double calculateInterest(double amount, double rate, int years) {
        return amount * rate * years / 100;
}
}
public class Bankutitlity {

	private static double calculateInterest;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		double interest = Bankutitlity.calculateInterest(1000, 5, 2);
        System.out.println("Calculated Interest: " + interest);

	}

	private static double calculateInterest(int i, int j, int k) {
		// TODO Auto-generated method stub
		return calculateInterest;
	}

}
