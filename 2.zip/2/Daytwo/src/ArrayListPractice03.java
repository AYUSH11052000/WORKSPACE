import java.util.ArrayList;
import java.util.List;

public class ArrayListPractice03 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<Employee>empList = new ArrayList<>();
		empList.add(new Employee(101,"Ayush", 30000.00));
	}

}
