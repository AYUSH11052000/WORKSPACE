
public class ArrayPractice1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*int[]values;
		values = new int[5];
		values[0]=10;
		values[1]=20;
		values[2]=30;
		values[3]=40;
		values[4]=50;
		System.out.println("Array size:" + values.length);*/
		int[]values=new int[5];
		int[] values1 = {10,20,30,40,50,};
		System.out.println("Array size:"+ values1.length);

	}

}
