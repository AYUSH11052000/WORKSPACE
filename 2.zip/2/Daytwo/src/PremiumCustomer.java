
public  class PremiumCustomer extends Customer{

	@Override
	public double CalculateDiscountRate(double orderTotal, double orderQuantity) {
		// TODO Auto-generated method stub
		double baseDiscount = 0.10;
		double additionalDiscount =0.02;
		return orderTotal>=50000.00 ? baseDiscount + additionalDiscount :baseDiscount;
	}

}
