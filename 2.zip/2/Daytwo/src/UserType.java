
public enum UserType {
	ADMIN,
	CUSTOMER,
	SUPPLIER,

}
