import java.util.Arrays;
import java.util.Scanner;
public class marks {

	public static void main(String[] args) {
		int[] m = {-1, 4, 0, 2, 7, -3};
        System.out.println("Original numeric array : " + Arrays.toString(m));
        int min = Integer.MAX_VALUE;
        int second_min = Integer.MAX_VALUE;
        for (int i = 0; i < m.length; i++) {
            if (m[i] == min) {
                second_min = min;
            } else if (m[i] < min) {
                second_min = min;
                min = m[i];
            } else if (m[i] < second_min) {
                second_min = m[i];
            }
        }
        System.out.println("Second lowest number is : " + second_min);
    }
}


