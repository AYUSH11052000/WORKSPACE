import java.util.Scanner;

public class meeee {
		    public static void main(String[] args) {
		       Scanner sc = new Scanner(System.in);
		       System.out.print("Enter you name:" );
		       String name = sc.nextLine();
		       System.out.println("Entered value: " + name);
		       sc.close();
		 
		    }
		}

