
public abstract class Customer extends User{
	private int customerNumber;
    private int bonusPoints;
    public Customer(){
	
}
public Customer(int customerNumber,int bonusPoints) {
	this.customerNumber = customerNumber;
	this.bonusPoints = bonusPoints;

}
public int getCustomerNumber() {
	return customerNumber;
}
public void setCustomerNumber(int customerNumber) {
	this.customerNumber = customerNumber;
}
public int getBonusPoints() {
	return bonusPoints;
}
public void setBonusPoints(int bonusPoints) {
	this.bonusPoints = bonusPoints;
}
public abstract double CalculateDiscountRate(double orderTotal, double orderQuantity);
}
