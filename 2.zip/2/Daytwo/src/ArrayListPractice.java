import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class ArrayListPractice {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*List list = new ArrayList<>();
		list.add(10);
		list.add("Aryan");
		list.add("Mahesh");
		list.add(10);
		list.add(34.2323F);
		list.add(43.65);
		System.out.println(list);*/
		List<String>nameList = new ArrayList<>();
		nameList.add("Devansh");
		nameList.add("Archit");
		nameList.addAll(Arrays.asList("Abhishek","Dhruv","Satyam","Ayush"));
		nameList.remove("Devansh");
		
		
		

	}

}
