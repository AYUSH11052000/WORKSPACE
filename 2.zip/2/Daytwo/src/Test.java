import java.util.Scanner;
public class Test {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		Customer customer = null;
		System.out.println("Enter a choice");
		int choice = scanner.nextInt();
		switch(choice){
		case 1:
			customer = new PlatinumCustomer();
			break;
		case 2:
			customer = new PremiumCustomer();
			break;
			default:
				System.out.println("Wrong choice");
			
		}
		customer.CalculateDiscountRate(56000.00, 8);
	}

}
