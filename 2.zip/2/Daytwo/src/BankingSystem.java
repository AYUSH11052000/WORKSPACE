import java.util.ArrayList;
import java.util.List;

abstract class BankAccount {
    protected String accountNumber;
    protected double balance;
    protected String accountHolder;
    protected List<String> transactionHistory;

    public BankAccount(String accountNumber, String accountHolder) {
        this.accountNumber = accountNumber;
        this.accountHolder = accountHolder;
        this.balance = 0.0;
        this.transactionHistory = new ArrayList<>();
    }

    public abstract void withdraw(double amount);
    public abstract void deposit(double amount);
    public abstract double calculateInterest();
    
    public void printTransactionHistory() {
        System.out.println("Transaction History for " + accountHolder + ":");
        for (String transaction : transactionHistory) {
            System.out.println(transaction);
        }
    }

    public double getBalance() {
        return balance;
    }
}

// Interface LoanEligibility
interface LoanEligibility {
    boolean checkLoanEligibility();
}

// RegularCustomerAccount
class RegularCustomerAccount extends BankAccount implements LoanEligibility {
    private static final double DAILY_WITHDRAWAL_LIMIT = 50000.0;
    private static final double LOW_BALANCE_RATE = 0.03;
    private static final double HIGH_BALANCE_RATE = 0.04;

    public RegularCustomerAccount(String accountNumber, String accountHolder) {
        super(accountNumber, accountHolder);
    }

    @Override
    public void withdraw(double amount) {
        if (amount > DAILY_WITHDRAWAL_LIMIT) {
            System.out.println("Withdrawal exceeds daily limit.");
            return;
        }
        if (amount > balance) {
            System.out.println("Insufficient funds.");
            return;
        }
        balance -= amount;
        transactionHistory.add("Withdrew: " + amount);
        System.out.println("Withdrawal successful: " + amount);
    }

    @Override
    public void deposit(double amount) {
        balance += amount;
        transactionHistory.add("Deposited: " + amount);
        System.out.println("Deposit successful: " + amount);
    }

    @Override
    public double calculateInterest() {
        return (balance < 100000) ? balance * LOW_BALANCE_RATE : balance * HIGH_BALANCE_RATE;
    }

    @Override
    public boolean checkLoanEligibility() {
        return balance >= 75000;
    }
}

// PremiumCustomerAccount
class PremiumCustomerAccount extends BankAccount implements LoanEligibility {
    private static final double WITHDRAWAL_FEE_THRESHOLD = 100000.0;
    private static final double HIGH_BALANCE_RATE = 0.06;
    private static final double LOW_BALANCE_RATE = 0.05;

    public PremiumCustomerAccount(String accountNumber, String accountHolder) {
        super(accountNumber, accountHolder);
    }

    @Override
    public void withdraw(double amount) {
        if (amount > balance) {
            System.out.println("Insufficient funds.");
            return;
        }
        double fee = (amount > WITHDRAWAL_FEE_THRESHOLD) ? amount * 0.01 : 0.0;
        balance -= (amount + fee);
        transactionHistory.add("Withdrew: " + amount + (fee > 0 ? " + Fee: " + fee : ""));
        System.out.println("Withdrawal successful: " + amount + (fee > 0 ? " + Fee: " + fee : ""));
    }

    @Override
    public void deposit(double amount) {
        balance += amount;
        transactionHistory.add("Deposited: " + amount);
        System.out.println("Deposit successful: " + amount);
    }

    @Override
    public double calculateInterest() {
        return (balance < 500000) ? balance * LOW_BALANCE_RATE : balance * HIGH_BALANCE_RATE;
    }

    @Override
    public boolean checkLoanEligibility() {
        return balance >= 200000; // Premium customers have a higher eligibility threshold
    }
}

// Main class to test the banking system
public class BankingSystem {
    public static void main(String[] args) {
        // Create instances of RegularCustomerAccount and PremiumCustomerAccount
        RegularCustomerAccount regularAccount = new RegularCustomerAccount("REG12345", "John Doe");
        PremiumCustomerAccount premiumAccount = new PremiumCustomerAccount("PREM54321", "Jane Smith");

        // Perform various operations
        regularAccount.deposit(80000);
        regularAccount.withdraw(30000);
        regularAccount.withdraw(60000); // Should exceed daily limit
        System.out.println("Regular Account Balance: " + regularAccount.getBalance());
        System.out.println("Regular Account Interest: " + regularAccount.calculateInterest());
        System.out.println("Loan Eligibility: " + regularAccount.checkLoanEligibility());
        regularAccount.printTransactionHistory();

        System.out.println();

        premiumAccount.deposit(600000);
        premiumAccount.withdraw(150000);
        System.out.println("Premium Account Balance: " + premiumAccount.getBalance());
        System.out.println("Premium Account Interest: " + premiumAccount.calculateInterest());
        System.out.println("Loan Eligibility: " + premiumAccount.checkLoanEligibility());
        premiumAccount.printTransactionHistory();
    }
}
