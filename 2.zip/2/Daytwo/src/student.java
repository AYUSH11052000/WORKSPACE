
public class student {
	private int rollNo;
	private String name;
	private  double[] marks;
	int getRollNo() {
		return rollNo;
	}
	public void setRollNo(int rollNo) {
		this.rollNo = rollNo;
	}
	public int getString() {
		int String = 0;
		return String;
	}
	public void setString(int string) {
		int String = string;
	}
	public double[] getMarks() {
		return marks;
	}
	public void setMark(double[] marks) {
		this.marks = marks;
	}
	public void setName(java.lang.String next) {
		// TODO Auto-generated method stub
		
	}
	public java.lang.String getName() {
		// TODO Auto-generated method stub
		return null;
	}
	
	

}
