import java.util.Scanner;
public class UserInterface 
{
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		//Fill code here
		System.out.println("Enter the name");
		String name = sc.nextLine();
		int numberofRooms = 0;
		while(numberofRooms<=0) {
			System.out.println("Enter the number of rooms you needed");
			numberofRooms = sc.nextInt();
			if(numberofRooms<=0) {
				System.out.println("Please enter valid number");
			}
			
		}
		System.out.println("Enter the phone number");
		Long phoneNumber =sc.nextLong();
		int roomRent =500;
		int totalAmount = numberofRooms * roomRent ;
		System.out.println("Pay " + totalAmount + " for booking");
		System.out.println("Your booking has been confirmed");
	}
}