 import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Stream;

public class UserInterface {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Prompt for the number of cartons
        System.out.println("Enter the number of cartons");
        int numCartons = scanner.nextInt();
        scanner.nextLine(); // Consume the newline character after integer input

        // Validate the number of cartons
        if (numCartons <= 0) {
            System.out.println("Invalid");
            return;
        }

        // Create a list to hold the carton details
        List<Carton> cartons = new ArrayList<>();

        // Input carton details
        for (int i = 0; i < numCartons; i++) {
            System.out.println("Enter carton details");
            String details = scanner.nextLine();
            String[] parts = details.split("/");

            // Validate input format and values
            if (parts.length != 3) {
                System.out.println("Invalid input format.");
                return;
            }

            String productName = parts[0];
            int quantity;
            double productCost;

            try {
                quantity = Integer.parseInt(parts[1]);
                productCost = Double.parseDouble(parts[2]);

                // Validate quantity
                if (quantity <= 0) {
                    System.out.println("Quantity number should be a valid number");
                    return;
                }

                // Create a new Carton object and add to the list
                Carton carton = new Carton();
                carton.setProductName(productName);
                carton.setQuantity(quantity);
                carton.setProductCost(productCost);
                cartons.add(carton);

            } catch (NumberFormatException e) {
                System.out.println("Quantity number should be a valid number");
                return;
            }
        }

        // Process the cartons using CartonUtility
        CartonUtility utility = new CartonUtility();
        utility.setCartonList(cartons);

        // Convert the list of cartons to a stream
        Stream<Carton> cartonStream = utility.convertToStream();

        // Find the carton with the maximum quantity
        Carton maxCarton = utility.findMax(cartonStream);

        if (maxCarton != null) {
            System.out.println(maxCarton.getProductName() + " had the highest quantity with " + maxCarton.getQuantity() + " nos");
        }
    }
}
