import java.util.Scanner;
import java.util.List;
import java.util.stream.Stream;

public class UserInterface {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        FruitBasketUtility utility = new FruitBasketUtility();
        
        while (true) {
            
            System.out.println("Select an option:");
            System.out.println("1.Add Fruit to Basket");
            System.out.println("2.Calculate Bill");
            System.out.println("3.Exit");

            int choice = scanner.nextInt();
            scanner.nextLine();  

            switch (choice) {
                case 1:
                    
                    System.out.println("Enter the fruit name");
                    String fruitName = scanner.nextLine();

                    System.out.println("Enter weight in Kgs");
                    int weightInKgs = scanner.nextInt();

                    System.out.println("Enter price per Kg");
                    int pricePerKg = scanner.nextInt();
                    scanner.nextLine();

                    FruitBasket fruit = new FruitBasket(fruitName, weightInKgs, pricePerKg);
                    utility.addToBasket(fruit);
                    break;

                case 2:
                    
                    List<FruitBasket> fruitBasketList = utility.getFruitBasketList();
                    if (fruitBasketList.isEmpty()) {
                        System.out.println("Your basket is empty. Please add fruits.");
                    } else {
                        
                        int totalBill = utility.calculateBill(fruitBasketList.stream());
                        System.out.println("The estimated bill amount is Rs " + totalBill);
                    }
                    break;

                case 3:
                   
                    System.out.println("Thank you for using the application.");
                    return;

                default:
                    
                    System.out.println("Invalid option. Please try again.");
            }
        }
    }
}
