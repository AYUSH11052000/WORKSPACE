import java.util.Scanner;
public class UserInterface {
    public static void main(String args[])
    {
    			// fill the code here
    			Scanner sc = new Scanner(System.in);
    	 
    			System.out.println("Enter the customer details");
    			String detailString = sc.next();
    	 
    			String[] strings = detailString.split(":");
    	 
    			int adult = Integer.parseInt(strings[1]);
    			int child = Integer.parseInt(strings[2]);
    			int days = Integer.parseInt(strings[3]);
    	 
    			if (adult < 0) {
    				System.out.println("Invalid input for number of adults");
    				return;
    			}
    			if (child < 0) {
    				System.out.println("Invalid input for number of children");
    				return;
    			}
    			if (days <= 0) {
    				System.out.println("Invalid input for number of days");
    				return;
    			}
    	 
    			System.out.println(strings[0] + " your booking is confirmed and the total cost is "
    					+ ((adult * 1000) + (child * 650)) * days);
    	 
    		}
    	 
    	}

 