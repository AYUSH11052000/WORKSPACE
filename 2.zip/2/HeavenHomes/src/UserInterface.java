import java.util.Scanner;

public class UserInterface {
    public static void main(String args[]) {
        Scanner sc = new Scanner(System.in);
       //Fill the code here
        Apartment apartment = new Apartment();
       System.out.println("Enter number of details to be added ");
       int details = sc.nextInt();
      System.out.println("Enter the details (Apartment number: Rent)");
      for(int i =0;i<details;i++){
          String input =sc.nextLine();
          String[] parts = input.split(":");
          String apartmentNumber = parts[0];
          double rent = Double.parseDouble(parts[1]);
          apartment.addApartmentDetails(apartmentNumber, rent);
      }

       
      System.out.println("Enter the range to filter the details");
      double minimumRent = sc.nextDouble();
      double maximumRent = sc.nextDouble();
      double totalRent = apartment.findTotalRentOfApartmentsInTheGivenRange(minimumRent, maximumRent);

      if (totalRent > 0) {
          System.out.printf("Total Rent in the range %.1f to %.1f USD:%.1f\n", minimumRent, maximumRent, totalRent);
      } else {
          System.out.println("No apartments found in this range");
      }

     
          
          
      }
       
    }
