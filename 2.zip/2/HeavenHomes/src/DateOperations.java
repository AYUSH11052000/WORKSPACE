		import java.text.ParseException;
		import java.text.SimpleDateFormat;
		import java.util.Date;

		public class DateOperations {

			public static void main(String[] args)   {
				// TODO Auto-generated method stub
				
				Date date = new Date();
				
				 
				try {
				SimpleDateFormat sdf = new SimpleDateFormat("dd-MMM-yy");
				
				Date date1 = sdf.parse("30-FEB-2024");
				
					
				System.out.println(sdf.format(date1));
				}catch(ParseException ps) {
					System.out.println(ps.getMessage());
					System.out.println("Invalid Date");
				}
/////REGEX DEMO

//public class RegexDemo {

	//public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		//regular expressions 
		
//		String mobileNumber = "7789292192";
//
//		
//		if(mobileNumber.matches("[6789]\\d{9}"))
//				System.out.println("Valid Mobile");
//		else 
//			System.out.println("Invalid");
		
		String str = "he$%23947832894";
		
		if(str.matches("^(?!.*[^a-zA-Z0-9-_]{2}).*$"))
			System.out.println(true);
		else
			System.out.println(false);
	}

}
		
		
			
