import java.io.File;

public class FileIOTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		File file= new File("abc.txt");

	}

}
