package com.demo.controllers;

import java.util.List;
 
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
 
import com.demo.models.Employee;
import com.demo.services.EmployeeService;
 
@RestController
public class EmployeeControllers {
	
	@Autowired
	private EmployeeService employeeService;
	
	public EmployeeControllers() {
		super();
	}
	
	
    @GetMapping("/api/employeees")
	public List<Employee> findAllEmployee(Employee employee) {
		
		return employeeService.findAllEmployee();
	}
    
    @GetMapping("/api/employeees/{id}")
	public Employee findEmployee(@PathVariable("id")int empId) {
    	return employeeService.findEmployee(empId);
    }
		
		//return employeeService.findAllEmployees();
 
 
}