package com.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Day1204SpringRestApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(Day1204SpringRestApiApplication.class, args);
	}

}
