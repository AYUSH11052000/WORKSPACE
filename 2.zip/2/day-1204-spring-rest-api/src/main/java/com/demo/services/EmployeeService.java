 package com.demo.services;
 
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
 
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
 
import com.demo.models.Employee;
import com.demo.repositories.EmployeeRepository;
 
@Service
public class EmployeeService {
	@Autowired
	private EmployeeRepository empRepo;
 
	public EmployeeService() {
		super();
	}
 
	public EmployeeService(EmployeeRepository empRepo) {
		super();
		this.empRepo = empRepo;
	}
	public Employee saveEmployee(Employee employee) {
		return empRepo.save(employee);
	}
	public Employee findEmployee(int id) {
		Optional<Employee> optionalEmoployee = empRepo.findById(id);
		if(optionalEmoployee.isPresent()) {
			return optionalEmoployee.get();
		}
		return null;
	}
	public void deleteEmployee(int id) {
		Optional<Employee> emp = empRepo.findById(id);
		if(emp.isPresent()) {
			empRepo.deleteById(id);
			System.out.println("Delete Succesfull");
		}
		else {
			System.out.println("Employee Not Found");
		}
	}

	public List<Employee> findAllEmployee() {
		List<Employee> li = new ArrayList<>();
		Iterable<Employee> allemp = empRepo.findAll();
		for(Employee e : allemp) {
			li.add(e);
		}
		return li;
	}

	public Employee updateEmp(int id) {
		Optional<Employee> updateemp = empRepo.findById(id);
		if(updateemp.isPresent()) {
			Employee emp = updateemp.get();
			emp.setEmpName("Verma");
			emp.setCityString("Lucknow");
			emp.setSalary(90000.00);
			return empRepo.save(emp);	
		}
		return null;
	}
}