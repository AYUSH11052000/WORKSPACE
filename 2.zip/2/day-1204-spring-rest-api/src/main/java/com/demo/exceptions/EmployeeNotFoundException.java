package com.demo.exceptions;

public class EmployeeNotFoundException extends RuntimeException{

}
