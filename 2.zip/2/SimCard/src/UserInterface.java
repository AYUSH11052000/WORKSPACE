import java.util.Scanner;

public class UserInterface{
    
    public static void main(String[] args){
        
       Scanner sc=new Scanner(System.in);
       
        //Fill the code here
       System.out.println("Enter the phone number");
       long PhoneNumber = sc.nextLong();
       long sumOdd =0;
       long sumEven=0;
       while(PhoneNumber>0){
    	   long digit =PhoneNumber%10;
    	   if(digit%2==0) {
    		   sumEven+= digit;
    	   }else {
    		   sumOdd+= digit;
    	   }
    	   PhoneNumber/=10;   
       }
       if(sumOdd>sumEven) {
    	   System.out.println("Sum of odd is greater than sum of even ");
       }
       if(sumOdd<sumEven) {
    	   System.out.println("Sum of even is greater than sum of odd");
       }
       if(sumOdd ==sumEven) {
    	   System.out.println("Sum of odd and even are equal");
       }
       
       
       
        
    }
}