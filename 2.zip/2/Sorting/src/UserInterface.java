import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class UserInterface {

	public static void main(String[] args) {
				
		Scanner sc = new Scanner(System.in);
		// Fill the code here
		System.out.println("Enter the products count");
		int count = sc.nextInt() ;
		if (count <= 0) {
            System.out.println("Invalid count");
            return;
        }
        ArrayList<Product> products = new ArrayList<>();
        		System.out.println("Enter Product details");
        sc.nextLine();   
        for (int i = 0; i <count; i++) {
            String productDetails = sc.nextLine();
            String[] details = productDetails.split(":");
            int productId = Integer.parseInt(details[0]);
            String productName = details[1];
            double price = Double.parseDouble(details[2]);
            
            Product product = new Product(productId, productName, price);
            products.add(product);
        }

                 System.out.println("1.Sort By Id");
        System.out.println("2.Sort By Price");
        System.out.println("Enter your choice");
        int choice = sc.nextInt();

                 if (choice == 1) {
                         Collections.sort(products, new SortById());
            System.out.println("After Sorting By Id");
        } else if (choice == 2) {
                         Collections.sort(products, new SortByPrice());
            System.out.println("After Sorting By Price");
        } else {
            System.out.println("Invalid choice");
            return;
        }

         
        for (Product product : products) {
            System.out.println(product);
        }
    }
}
	