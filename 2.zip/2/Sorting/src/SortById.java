import java.util.Comparator;

public class SortById implements Comparator<Product>{
	@Override
	public int compare(Product a, Product b) {
		// TODO Auto-generated method stub
		return Integer.compare(a.getProductid(), b.getProductid());
	}
	
}
