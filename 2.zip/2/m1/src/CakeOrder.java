import java.util.Map;
import java.util.HashMap;
		public class CakeOrder {

		    // Attribute to store the order details
		    private Map<String, Double> orderMap;

		    // Constructor to initialize the orderMap
		    public CakeOrder() {
		        orderMap = new HashMap<>();
		    }

		    // Getter for orderMap
		    public Map<String, Double> getOrderMap() {
		        return orderMap;
		    }

		    // Setter for orderMap
		    public void setOrderMap(Map<String, Double> orderMap) {
		        this.orderMap = orderMap;
		    }

		    // Method to add a cake order to the orderMap
		    public void addOrderDetails(String orderId, double cakeCost) {
		        orderMap.put(orderId, cakeCost);
		    }

		    // Method to find orders above a specified cake cost
		    public Map<String, Double> findOrdersAboveSpecifiedCost(double cakeCost) {
		        Map<String, Double> result = new HashMap<>();
		        
		        // Iterate through the orderMap and filter orders
		        for (Map.Entry<String, Double> entry : orderMap.entrySet()) {
		            if (entry.getValue() > cakeCost) {
		                result.put(entry.getKey(), entry.getValue());
		            }
		        }
		        
		        return result;
		    }
		}


