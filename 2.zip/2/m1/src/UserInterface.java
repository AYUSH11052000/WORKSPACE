		import java.util.Map;
		import java.util.Scanner;

		public class UserInterface {

		    public static void main(String[] args) {
		        CakeOrder cakeOrder = new CakeOrder();
		        Scanner sc = new Scanner(System.in);
		        System.out.println("Enter number of cake orders to be added");
		        int numOrders = sc.nextInt();
		        sc.nextLine();  
		        System.out.println("Enter the cake order details (Order Id: CakeCost)");
		        for (int i = 0; i < numOrders; i++) {
		            String orderDetails = sc.nextLine();
		            
		            String[] orderParts = orderDetails.split(":");
		            if(orderParts.length==2) {
		            String orderId = orderParts[0];
		            double cakeCost = Double.parseDouble(orderParts[1]);
		            cakeOrder.addOrderDetails(orderId, cakeCost);}
		        }
		        System.out.println("Enter the cost to search the cake orders");
		        double searchCost = sc.nextDouble();
		        Map<String, Double> filteredOrders = cakeOrder.findOrdersAboveSpecifiedCost(searchCost);
		        if (filteredOrders.isEmpty()) {
		            System.out.println("No cake orders found");
		        } else {
		            System.out.println("Cake Orders above the specified cost");
		            for (Map.Entry<String, Double> entry : filteredOrders.entrySet()) {
		                System.out.println("Order ID: " + entry.getKey() + ", Cake Cost: " + entry.getValue());
		            }
		        }

		      
		    }
		}

