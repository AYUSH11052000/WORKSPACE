import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class CarPoolingSystem {
	private static List<Member> members = new ArrayList<>();
    private static List<Car> cars = new ArrayList<>();
    private static List<MemberCar> memberCars = new ArrayList<>();


	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner = new Scanner(System.in);
        while (true) {
            System.out.println("Menu:");
            System.out.println("1) Add a Member");
            System.out.println("2) Add a Car");
            System.out.println("3) Assign Car to Member");
            System.out.println("4) Cars Owned");
            System.out.println("5) Exit");
            int choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1:
                    System.out.println("Enter Member details: id, first name, last name, email, contact number, license number, license start date, license expiry date");
                    Long memberId = scanner.nextLong();
                    scanner.nextLine(); 
                    String firstName = scanner.nextLine();
                    String lastName = scanner.nextLine();
                    String email = scanner.nextLine();
                    String contactNumber = scanner.nextLine();
                    String licenseNumber = scanner.nextLine();
                    String licenseStartDate = scanner.nextLine();
                    String licenseExpiryDate = scanner.nextLine();

                    Member member = new Member(memberId , firstName, lastName, email, contactNumber, licenseNumber, licenseStartDate, licenseExpiryDate);
                    members.add(member);
                    break;

                case 2:
                    System.out.println("Enter Car details: id, name, model, makeYear, company, comfortLevel");
                    Long carId = scanner.nextLong();
                    scanner.nextLine(); 
                    String name = scanner.nextLine();
                    String model = scanner.nextLine();
                    Integer makeYear = scanner.nextInt();
                    scanner.nextLine();
                    String company = scanner.nextLine();
                    Integer comfortLevel = scanner.nextInt();
                    
                    Car car = new Car(carId, name, model, makeYear, company, comfortLevel);
                    cars.add(car);
                    break;

                case 3:
                    System.out.println("Enter MemberCar details: member car id, member id, car id, car registration number, car color");
                    Long memberCarId = scanner.nextLong();
                    Long memberIdForCar = scanner.nextLong();
                    Long carIdForMember = scanner.nextLong();
                    scanner.nextLine(); 
                    String registrationNumber = scanner.nextLine();
                    String carColor = scanner.nextLine();

                    Member memberForCar = Member.findMember(memberIdForCar, members);
                    Car carForMember = Car.findCar(carIdForMember, cars);

                    if (memberForCar != null && carForMember != null) {
                        MemberCar memberCar = new MemberCar();
                        memberForCar.getCarList().add(memberCar);
                        memberCars.add(memberCar);
                    } else {
                        System.out.println("Invalid Member or Car ID");
                    }
                    break;

                case 4:
                    System.out.println("Enter Member id to view cars owned:");
                    Long memberIdToCheck = scanner.nextLong();
                    Member memberToCheck = Member.findMember(memberIdToCheck, members);
                    if (memberToCheck != null) {
                        memberToCheck.displayCarsOwned();
                    } else {
                        System.out.println("Member not found");
                    }
                    break;

                case 5:
                   
                    System.out.println("Exiting...");
                    scanner.close();
                    return;
            }
        }
    }
}

		
		
