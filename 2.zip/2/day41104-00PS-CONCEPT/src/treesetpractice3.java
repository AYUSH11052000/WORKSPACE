import java.util.Comparator;
import java.util.Set;
import java.util.TreeSet;

public class treesetpractice3 {

	public static void main(String[] args) {
		import java.util.Scanner;

		public class NumberGame {

		    public static void main(String[] args) {
		        Scanner scanner = new Scanner(System.in);

		        // Step 1: Read the size of the first array
		        System.out.println("Enter the size of first array");
		        int size1 = scanner.nextInt();

		        // Validate the size of the first array
		        if (size1 <= 0) {
		            System.out.println(size1 + " is an invalid array size");
		            return; // Terminate the program if size is invalid
		        }

		        // Step 2: Read the elements of the first array
		        int[] array1 = new int[size1];
		        System.out.println("Enter the array elements");
		        for (int i = 0; i < size1; i++) {
		            array1[i] = scanner.nextInt();
		            if (array1[i] < 0) {
		                System.out.println(array1[i] + " is an invalid input");
		                return; // Terminate if invalid input
		            }
		        }

		        // Step 3: Read the size of the second array
		        System.out.println("Enter the size of second array");
		        int size2 = scanner.nextInt();

		        // Validate the size of the second array
		        if (size2 <= 0) {
		            System.out.println(size2 + " is an invalid array size");
		            return; // Terminate the program if size is invalid
		        }

		        // Step 4: Check if both arrays have the same size
		        if (size1 != size2) {
		            System.out.println("Both array size is different");
		            return; // Terminate the program if sizes are different
		        }

		        // Step 5: Read the elements of the second array
		        int[] array2 = new int[size2];
		        System.out.println("Enter the array elements");
		        for (int i = 0; i < size2; i++) {
		            array2[i] = scanner.nextInt();
		            if (array2[i] < 0) {
		                System.out.println(array2[i] + " is an invalid input");
		                return; // Terminate if invalid input
		            }
		        }

		        // Step 6: Add corresponding elements from array1 and array2 to form array3
		        int[] array3 = new int[size1];
		        for (int i = 0; i < size1; i++) {
		            array3[i] = array1[i] + array2[i];
		        }

		        // Step 7: Sum the last digits of all elements in array3
		        int lastDigitSum = 0;
		        for (int num : array3) {
		            lastDigitSum += num % 10; // Add the last digit
		        }

		        // Step 8: Check if the sum of last digits is prime
		        if (isPrime(lastDigitSum)) {
		            System.out.println(lastDigitSum + " is a prime number");
		        } else {
		            System.out.println(lastDigitSum + " is not a prime number");
		        }
		    }

		    // Method to check if a number is prime
		    private static boolean isPrime(int num) {
		        if (num <= 1) {
		            return false; // Numbers less than or equal to 1 are not prime
		        }
		        for (int i = 2; i * i <= num; i++) {
		            if (num % i == 0) {
		                return false; // Not prime if divisible by any number other than 1 and itself
		            }
		        }
		        return true;
		    }
		}


	}

}

