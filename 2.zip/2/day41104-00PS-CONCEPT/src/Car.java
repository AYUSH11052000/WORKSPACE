import java.util.List;

public class Car {
	private Long id;
	private String name;
	private String model;
	private Integer makeYear;
	private String company;
	private Integer comfortLevel;
	public Car() {
		
	}
	public Car(Long id , String name, String model, Integer makeYear, String company ,Integer comfortLevel) {
		this.id =id;
		this.name= name;
		this.model=model;
		this.makeYear=makeYear;
		this.company=company;
		this.comfortLevel=comfortLevel;
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getModel() {
		return model;
	}
	public void setModel(String model) {
		this.model = model;
	}
	public Integer getMakeYear() {
		return makeYear;
	}
	public void setMakeYear(Integer makeYear) {
		this.makeYear = makeYear;
	}
	public String getCompany() {
		return company;
	}
	public void setCompany(String company) {
		this.company = company;
	}
	public Integer getComfortLevel() {
		return comfortLevel;
	}
	public void setComfortLevel(Integer comfortLevel) {
		this.comfortLevel = comfortLevel;
	}
	public static Car findCar(Long id, List<Car> cars) {
        for (Car car : cars) {
            if (car.getId().equals(id)) {
                return car;
            }
        }
        return null;
    }
}

