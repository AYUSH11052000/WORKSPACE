import java.util.HashMap;
import java.util.Map;

public class HashMapPractice01 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Map<Integer,String>map =new HashMap<>();
		map.put(101,"Mahesh");
		map.put(102,"Suresh");
		map.put(103,"Dinesh");
		map.put(104,"Jignesh");
		map.put(105,"Ramesh");
		map.put(106,"Dinesh");
		map.put(104,"Hitesh");
		System.out.println(map);





	}

}
