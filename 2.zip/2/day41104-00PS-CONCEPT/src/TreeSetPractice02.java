import java.util.Set;
import java.util.TreeSet;

public class TreeSetPractice02 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*Set<Integer>evenNumbers = new TreeSet<>();
		evenNumbers.add(2);
		evenNumbers.add(4);
		evenNumbers.add(6);
		System.out.println("Tree set :" + evenNumbers);
		Set<Integer>Numbers = new TreeSet<>();
		Numbers.add(1);
		Numbers.addAll(evenNumbers);
		System.out.println(Numbers);*/

			TreeSet<String> set1 = new TreeSet<String>(); 
				set1.add("A"); 
				set1.add("B"); 
				set1.add("C"); 
				set1.add("D"); 
				set1.add("E"); 
				set1.add("A");
		System.out.println("First TreeSet: "+ set1); 
		TreeSet<String> set2 = new TreeSet<String>(); 
				set2.add("A"); 
				set2.add("B"); 
				set2.add("C"); 
				set2.add("D"); 
				set2.add("E"); 
		System.out.println("Second TreeSet: "+ set2); 
				boolean value = set1.equals(set2); 
				System.out.println("Are both set equal: " + value);

	}

}
