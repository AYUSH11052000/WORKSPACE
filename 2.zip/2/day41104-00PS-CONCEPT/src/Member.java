import java.util.ArrayList;
import java.util.List;

public class Member {
	private Long id;
    private String firstName;
    private String lastName;
    private String email;
    private String contactNumber;
    private String licenseNumber;
    private String licenseStartDate;
    private String licenseExpiryDate;
    private List<MemberCar> carList = new ArrayList<>();
	public Member(Long id, String firstName, String lastName, String email, String contactNumber, String licenseNumber,
			String licenseStartDate, String licenseExpiryDate, List<MemberCar> carList) {
		super();
		this.id = id;
		this.firstName = firstName;
		this.lastName = lastName;
		this.email = email;
		this.contactNumber = contactNumber;
		this.licenseNumber = licenseNumber;
		this.licenseStartDate = licenseStartDate;
		this.licenseExpiryDate = licenseExpiryDate;
		this.carList = carList;
	}
	public Member(Long memberId, String firstName2, String lastName2, String email2, String contactNumber2,
			String licenseNumber2, String licenseStartDate2, String licenseExpiryDate2) {
		// TODO Auto-generated constructor stub
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getContactNumber() {
		return contactNumber;
	}
	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}
	public String getLicenseNumber() {
		return licenseNumber;
	}
	public void setLicenseNumber(String licenseNumber) {
		this.licenseNumber = licenseNumber;
	}
	public String getLicenseStartDate() {
		return licenseStartDate;
	}
	public void setLicenseStartDate(String licenseStartDate) {
		this.licenseStartDate = licenseStartDate;
	}
	public String getLicenseExpiryDate() {
		return licenseExpiryDate;
	}
	public void setLicenseExpiryDate(String licenseExpiryDate) {
		this.licenseExpiryDate = licenseExpiryDate;
	}
	public List<MemberCar> getCarList() {
		return carList;
	}
	public void setCarList(List<MemberCar> carList) {
		this.carList = carList;
	}
	public static Member findMember(Long id, List<Member> members) {
        for (Member member : members) {
            if (member.getId().equals(id)) {
                return member;
            }
        }
        return null;
    }
    public void displayCarsOwned() {
        System.out.println("Number of cars: " + carList.size());
        System.out.println("Registration Numbers:");
        for (MemberCar memberCar : carList) {
            System.out.println(memberCar.getCarRegistrationNumber());
        }
	

}
}
