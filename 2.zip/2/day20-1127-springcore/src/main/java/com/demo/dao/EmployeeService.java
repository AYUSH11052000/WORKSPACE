package com.demo.dao;

	import com.demo.dao.EmployeeDAO;
	 
	public class EmployeeService {
	 
		private EmployeeDAO employeeService;
		public EmployeeService() {
			// TODO Auto-generated constructor stub
			System.out.println("EmployeeService object is created");
		}
		public EmployeeService(EmployeeDAO employeeService) {
			super();
			this.employeeService = employeeService;
			System.out.println("EmployeeService object is created and initialised");
		}
		public EmployeeDAO getEmployeeService() {
			return employeeService;
		}
		public void setEmployeeService(EmployeeDAO employeeService) {
			this.employeeService = employeeService;
		}
  
	 

}
