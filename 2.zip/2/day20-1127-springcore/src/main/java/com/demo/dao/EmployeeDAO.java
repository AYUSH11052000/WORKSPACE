package com.demo.dao;

public class EmployeeDAO {
	private EmployeeDAO employeeService;
	public EmployeeDAO() {
		
	}

}
