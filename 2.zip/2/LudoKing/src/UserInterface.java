import java.util.Scanner;
public class UserInterface
{
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		//Fill code here 
		int alexPoints= 0;
		int nikilPoints= 0;
		int samPoints= 0;
		System.out.println("Enter Alex points");
		alexPoints = sc.nextInt();
		System.out.println("Enter Nikil points");
		alexPoints = sc.nextInt();
		System.out.println("Enter Sam points");
		alexPoints = sc.nextInt();
		if (alexPoints<0 || alexPoints>50 || nikilPoints<0 || nikilPoints>50 || samPoints<0 || samPoints>50) {
			System.out.println("Invalid number! Point should be between 0 to 50.");
			return;		
		}
		if (alexPoints == nikilPoints||nikilPoints == samPoints||samPoints==alexPoints) {
			System.out.println("The game is a tie");
		}
		if(alexPoints> samPoints && alexPoints> nikilPoints) {
			System.out.println("Alex scores"+ alexPoints +"Point and won the game");
		}
		if( nikilPoints> samPoints &&  nikilPoints>alexPoints) {
			System.out.println("nikil scores"+ nikilPoints +"Point and won the game");       
        }
		if( samPoints>nikilPoints &&  samPoints>alexPoints) {
		}
}
}