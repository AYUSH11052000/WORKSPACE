import javax.sql.DataSource;

import org.apache.commons.dbcp2.BasicDataSource;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.impl.BankServiceImpl;

import com.impl.JDBCAccountImpl;

import com.impl.JDBCRewardRepositoryImpl;

import com.impl.JDBCTransactionRepositoryImpl;

import com.model.EmailService;

import com.repo.AccountRepository;

import com.repo.BankService;

import com.repo.RewardRepository;

import com.repo.TransactionRepository;
 
@Configuration

public class Appconfig {
 
@Bean

	public BasicDataSource createDataSource() {
 
		BasicDataSource dataSource = new BasicDataSource();
		
		dataSource.setUrl("jdbc:postgresql://localhost:5434/Banking");

		dataSource.setUsername("postgres");

		dataSource.setPassword("root123");

		
 
		return dataSource;

	}
 
@Bean

	public AccountRepository createAccountRepository(BasicDataSource dataSource) {

		return new JDBCAccountImpl(dataSource);

	}
 
	@Bean

	public RewardRepository createRewardRepository(BasicDataSource dataSource) {

		return new JDBCRewardRepositoryImpl(dataSource);

	}
 
	@Bean

	public TransactionRepository createTransactionRepository(BasicDataSource dataSource) {

		return new JDBCTransactionRepositoryImpl(dataSource);

	}
 
	@Bean

	public EmailService emailService(BasicDataSource dataSource) {

		return new EmailService();

	}
 
	@Bean

	public BankService createBankService(BasicDataSource dataSource, AccountRepository accountRepo,

			TransactionRepository transactionRepo, EmailService emailService) {

		return new BankServiceImpl(accountRepo, transactionRepo, emailService, dataSource);

	}
 
}

 
 