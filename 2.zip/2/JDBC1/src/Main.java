 import java.util.*;
 
import org.springframework.context.ApplicationContext;
 
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
 
import com.impl.*;
 
import com.model.*;
 
import com.repo.*;
 
public class Main {
 
	private static BankService bankService;
 
	private static Scanner scanner = new Scanner(System.in);
 
	static JDBCAccountImpl jdbcAccountImpl;
 
	static JDBCTransactionRepositoryImpl jdbcTransactionRepository;
 
	public static void main(String[] args) {
 
		ApplicationContext context = new AnnotationConfigApplicationContext(Appconfig.class);
 
		jdbcAccountImpl = context.getBean(JDBCAccountImpl.class);
 
		jdbcTransactionRepository = context.getBean(JDBCTransactionRepositoryImpl.class);
 
		EmailService emailService = context.getBean(EmailService.class);
 
		BankService bankService = context.getBean(BankServiceImpl.class);
 
		while (true) {
 
			System.out.println("Welcome to the Bank");
 
			System.out.println("1. Create New Account");
 
			System.out.println("2. View All Accounts");
 
			System.out.println("3. Transfer Money");
 
			System.out.println("4. Debit Money");
 
			System.out.println("5. Credit Money");
 
			System.out.println("6. Activate Account");
 
			System.out.println("7. Deactivate Account");
 
			System.out.println("8. View All Transactions");
 
			System.out.println("9. View Rewards");
 
			System.out.println("10. Exit");
 
			System.out.print("Select an option: ");
 
			int choice = scanner.nextInt();
 
			scanner.nextLine(); // Consume the newline character
 
			// Handle different user choices
 
			switch (choice) {
 
			case 1:
 
				createNewAccount();
 
				break;
 
			case 2:
 
				viewAllAccounts();
 
				break;
 
			case 3:
 
				transferMoney(bankService);
 
				break;
 
			case 4:
 
				debitMoney(bankService);
 
				break;
 
			case 5:
 
				creditMoney(bankService);
 
				break;
 
			case 6:
 
				activateAccount();
 
				break;
 
			case 7:
 
				deactivateAccount();
 
				break;
 
			case 8:
 
				viewTransactions();
 
				break;
 
			case 9:
 
				viewRewards();
 
				break;
 
			case 10:
 
				System.out.println("Exiting the system.");
 
				System.exit(0); // Exit the program
 
				break;
 
			default:
 
				System.out.println("Invalid choice! Please try again.");
 
			}
 
		}
 
	}
 
	private static void createNewAccount() {
 
		System.out.println("Enter account number:");
 
		long accountNumber = scanner.nextLong();
 
		scanner.nextLine(); // Consume the newline character
 
		System.out.println("Enter account holder name:");
 
		String name = scanner.nextLine();
 
		System.out.println("Enter balance:");
 
		int balance = scanner.nextInt();
 
		scanner.nextLine(); // Consume the newline character
 
		System.out.println("Enter email address:");
 
		String email = scanner.nextLine();
 
		System.out.println("Enter city:");
 
		String city = scanner.nextLine();
 
		System.out.println("Enter country:");
 
		String country = scanner.nextLine();
 
		Address address = new Address(city, country);
 
		Account account = new Account(accountNumber, name, true, address, balance, email);
 
		// Call bank service to create new account
 
		bankService.createNewAccount(account);
 
		System.out.println("Account created successfully.");
 
	}
 
	private static void viewAllAccounts() {
 
		List<Account> accounts = bankService.getAllAccounts();
 
		for (Account account : accounts) {
 
			System.out.println(account);
 
		}
 
	}
 
	private static void transferMoney(BankService bankService) {
 
		System.out.println("Enter sender account number:");
 
		long fromAccount = scanner.nextLong();
 
		System.out.println("Enter receiver account number:");
 
		long toAccount = scanner.nextLong();
 
		System.out.println("Enter amount to transfer:");
 
		int amount = scanner.nextInt();
 
		// Perform the transfer and display success or failure
 
		long transferredAmount = bankService.transfer(fromAccount, toAccount, amount);
 
		if (transferredAmount != -1) {
 
			System.out.println("Transfer successful: " + transferredAmount + " has been transferred.");
 
		} else {
 
			System.out.println("Transfer failed.");
 
		}
 
	}
 
	private static void debitMoney(BankService bankService) {
 
		System.out.println("Enter account number:");
 
		long accountNumber = scanner.nextLong();
 
		System.out.println("Enter amount to debit:");
 
		int amount = scanner.nextInt();
 
		long newBalance = bankService.debit(amount, accountNumber);
 
		if (newBalance != -1) {
 
			System.out.println("Debit successful. New balance: " + newBalance);
 
		} else {
 
			System.out.println("Debit failed.");
 
		}
 
	}
 
	private static void creditMoney(BankService bankService) {
 
		System.out.println("Enter account number:");
 
		long accountNumber = scanner.nextLong();
 
		System.out.println("Enter amount to credit:");
 
		int amount = scanner.nextInt();
 
		// Perform the credit and display the new balance or failure
 
		long newBalance = bankService.credit(amount, accountNumber);
 
		if (newBalance != -1) {
 
			System.out.println("Credit successful. New balance: " + newBalance);
 
		} else {
 
			System.out.println("Credit failed.");
 
		}
 
	}
 
	private static void activateAccount() {
 
		System.out.println("Enter account number to activate:");
 
		long accountNumber = scanner.nextLong();
 
		// Activate the account
 
		bankService.activateAccount(accountNumber);
 
		System.out.println("Account activated.");
 
	}
 
	private static void deactivateAccount() {
 
		System.out.println("Enter account number to deactivate:");
 
		long accountNumber = scanner.nextLong();
 
		// Deactivate the account
 
		bankService.deactivateAccount(accountNumber);
 
		System.out.println("Account deactivated.");
 
	}
 
	private static void viewTransactions() {
 
		System.out.println("Enter account number to view transactions:");
 
		long accountNumber = scanner.nextLong();
 
		// Retrieve and display the transactions for the account
 
		List<TransactionDetail> transactions = Main.jdbcTransactionRepository
 
				.getAllTransactionDetailsByAccountNumber(accountNumber);
 
		if (transactions != null && !transactions.isEmpty()) {
 
			for (TransactionDetail transaction : transactions) {
 
				System.out.println(transaction);
 
			}
 
		} else {
 
			System.out.println("No transactions found for this account.");
 
		}
 
	}
 
	private static void viewRewards() {
 
		System.out.println("Enter account number to view rewards:");
 
		long accountNumber = scanner.nextLong();
 
		// Retrieve and display rewards for the account
 
		RewardRepository rewardRepository = new JDBCRewardRepositoryImpl();
 
		List<Reward> rewards = rewardRepository.getAllRewardsForAccount(accountNumber);
 
		if (rewards != null && !rewards.isEmpty()) {
 
			for (Reward reward : rewards) {
 
				System.out.println("Reward: " + reward.getRewardAmount());
 
			}
 
		} else {
 
			System.out.println("No rewards found for this account.");
 
		}
 
	}
 
}
 