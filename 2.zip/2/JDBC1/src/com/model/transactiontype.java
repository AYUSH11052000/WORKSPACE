package com.model;
public enum transactiontype {
    CREDIT,
    DEBIT;
}
