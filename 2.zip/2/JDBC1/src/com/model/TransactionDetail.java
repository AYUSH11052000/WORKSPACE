package com.model;
import java.util.Date;

public class TransactionDetail {

    private static long transactionid;
    private long accountnumber;
    private Date transactiondate;
    private int amount;
    private transactiontype txtype;

    public TransactionDetail(long transactionId, long accountnumber, Date transactiondate, int amount, transactiontype txtype) {
        super();
        TransactionDetail.transactionid = transactionId;
        this.accountnumber = accountnumber;
        this.transactiondate = transactiondate;
        this.amount = amount;
        this.txtype = txtype;
    }

    public long getTransactionid() {
        return transactionid++;
        
    }

    public void setTransactionid(long transactionid) {
        TransactionDetail.transactionid = transactionid;
        transactionid++;
    }

    public long getAccountnumber() {
        return accountnumber;
    }

    public void setAccountnumber(long accountnumber) {
        this.accountnumber = accountnumber;
    }

    public Date getTransactiondate() {
        return transactiondate;
    }

    public void setTransactiondate(Date transactiondate) {
        this.transactiondate = transactiondate;
    }

    public int getAmount() {
        return amount;
    }

    public void setAmount(int amount) {
        this.amount = amount;
    }

    public transactiontype getTxtype() {
        return txtype;
    }

    public void setTxtype(transactiontype txtype) {
        this.txtype = txtype;
    }

    @Override
    public String toString() {
        return "TransactionDetail [transactionid=" + transactionid + ", accountnumber=" + accountnumber
                + ", transactiondate=" + transactiondate + ", amount=" + amount + ", txtype=" + txtype + "]";
    }
}
