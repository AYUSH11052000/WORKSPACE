package com.impl;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import com.db.DBUtil;
import com.model.Reward;
import com.repo.RewardRepository;

public class JDBCRewardRepositoryImpl implements RewardRepository {
	private DataSource dataSource;

	public JDBCRewardRepositoryImpl(DataSource dataDource) {
		super();
		this.dataSource = dataDource;
	}

	public JDBCRewardRepositoryImpl() {
		super();
	}

    @Override
    public void addReward(Reward reward) {
        String query = "INSERT INTO reward (rewardAmount, accountNumber) VALUES (?, ?)";

        try (Connection conn = dataSource.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query, Statement.RETURN_GENERATED_KEYS)) {

            stmt.setInt(1, reward.getRewardAmount());
            stmt.setLong(2, reward.getAccountNumber());

            int affectedRows = stmt.executeUpdate();
            if (affectedRows > 0) {
                try (ResultSet generatedKeys = stmt.getGeneratedKeys()) {
                    if (generatedKeys.next()) {
                        reward.setRewardConfirmationNumber(generatedKeys.getLong(1));
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public int getTotalRewardAmount(Long accountNumber) {
        String query = "SELECT SUM(rewardAmount) AS totalRewards FROM reward WHERE accountNumber = ?";
        int totalRewards = 0;

        try (Connection conn = dataSource.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setLong(1, accountNumber);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                totalRewards = rs.getInt("totalRewards");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return totalRewards;
    }

    @Override
    public List<Reward> getAllRewardsForAccount(Long accountNumber) {
        List<Reward> rewards = new ArrayList<>();
        String query = "SELECT * FROM reward WHERE accountNumber = ?";

        try (Connection conn = dataSource.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setLong(1, accountNumber);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                Reward reward = new Reward(
                        rs.getLong("rewardConfirmationNumber"),
                        rs.getInt("rewardAmount"),
                        rs.getLong("accountNumber")
                );
                rewards.add(reward);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return rewards;
    }
}
