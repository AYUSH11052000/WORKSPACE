package com.impl;
import java.util.Date;
import java.util.List;

import org.apache.commons.dbcp2.BasicDataSource;

import com.model.Account;
import com.model.EmailService;
import com.model.TransactionDetail;
import com.model.transactiontype;
import com.repo.AccountRepository;
import com.repo.BankService;
import com.repo.TransactionRepository;

public class BankServiceImpl implements BankService {

    private AccountRepository accountRepo;
    private TransactionRepository transactionRepo;
    private EmailService emailService;
    private BasicDataSource dataSource;

    public BankServiceImpl(AccountRepository accountRepo, TransactionRepository transactionRepo, 
                           EmailService emailService,BasicDataSource dataSource) {
        this.accountRepo = accountRepo;
        this.transactionRepo = transactionRepo;
        this.emailService = emailService;
    }

    @Override
    public long transfer(long fromAccount, long toAccount, int amount) {
        Account account1 = accountRepo.findAccountByNumber(fromAccount);
        Account account2 = accountRepo.findAccountByNumber(toAccount);

        if (account1 == null || account2 == null || account1.getBalance() < amount) {
            return -1;
        }

        long senderBalance = debit(amount, fromAccount);
        if (senderBalance == -1) {
            return -1; 
        }

        long receiverBalance = credit(amount, toAccount);
        if (receiverBalance == -1) {
            rollbackDebit(amount, fromAccount);
            return -1;
        }

        if (!addTransaction(fromAccount, amount, transactiontype.DEBIT) || 
            !addTransaction(toAccount, amount, transactiontype.CREDIT)) {
            rollbackDebit(amount, fromAccount);
            rollbackCredit(amount, toAccount);
            return -1;
        }

        sendTransferNotification(account1.getEmailaddress(), account2.getEmailaddress(), fromAccount, amount);

        return amount;
    }

    private boolean addTransaction(long accountNumber, int amount, transactiontype type) {
        try {
            long transactionId = generateTransactionId();
            TransactionDetail transaction = new TransactionDetail(transactionId, accountNumber, new Date(), amount, type);
            transactionRepo.addTransaction(transaction);
            return true;
        } catch (Exception e) {
            System.out.println("Error adding transaction: " + e.getMessage());
            return false;
        }
    }

    private void sendTransferNotification(String senderEmail, String receiverEmail, long fromAccount, int amount) {
        try {
            String transferMessage = String.format("Transfer successful: %d has been transferred from your account %d.", amount, fromAccount);
            String receivedMessage = String.format("Transfer received: You have received %d from account %d.", amount, fromAccount);
            emailService.sendMail(senderEmail, "bank@example.com", "", transferMessage);
            emailService.sendMail(receiverEmail, "bank@example.com", "", receivedMessage);
        } catch (Exception e) {
            System.out.println("Failed to send email notifications.");
        }
    }

    private long generateTransactionId() {
        return (long) (Math.random() * Long.MAX_VALUE);
    }

    @Override
    public long debit(int amount, long accountNumber) {
        Account account = accountRepo.findAccountByNumber(accountNumber);
        if (account != null && account.getBalance() >= amount) {
            account.setBalance(account.getBalance() - amount);
            accountRepo.update(account);

            if (addTransaction(accountNumber, amount, transactiontype.DEBIT)) {
                sendDebitNotification(account, amount);
                return account.getBalance();
            }
        }
        return -1; 
    }

    private void sendDebitNotification(Account account, int amount) {
        try {
            String message = String.format("Your account has been debited with %d. Your new balance is %d.", amount, account.getBalance());
            emailService.sendMail(account.getEmailaddress(), "bank@example.com", "Debit Notification", message);
        } catch (Exception e) {
            System.out.println("Failed to send email notification.");
        }
    }

    @Override
    public long credit(int amount, long accountNumber) {
        Account account = accountRepo.findAccountByNumber(accountNumber);
        if (account != null) {
            account.setBalance(account.getBalance() + amount);
            accountRepo.update(account);

            if (addTransaction(accountNumber, amount, transactiontype.CREDIT)) {
                return account.getBalance();
            }
        }
        return -1; 
    }

    private void rollbackDebit(int amount, long accountNumber) {
        Account account = accountRepo.findAccountByNumber(accountNumber);
        if (account != null) {
            account.setBalance(account.getBalance() + amount); 
            accountRepo.update(account);
        }
    }

    private void rollbackCredit(int amount, long accountNumber) {
        Account account = accountRepo.findAccountByNumber(accountNumber);
        if (account != null) {
            account.setBalance(account.getBalance() - amount);  
            accountRepo.update(account);
        }
    }

    @Override
    public void createNewAccount(Account account) {
        accountRepo.save(account);
    }

    @Override
    public void deactivateAccount(long accountNumber) {
        Account account = accountRepo.findAccountByNumber(accountNumber);
        if (account != null) {
            account.setIsactive(false);
            accountRepo.update(account);
        }
    }

    @Override
    public void activateAccount(long accountNumber) {
        Account account = accountRepo.findAccountByNumber(accountNumber);
        if (account != null) {
            account.setIsactive(true);
            accountRepo.update(account);
        }
    }

    @Override
    public List<Account> getAllAccounts() {
        return accountRepo.findAllAccounts();
    }
}
