package com.repo;
import java.util.List;

import com.model.Reward;

public interface RewardRepository {
    void addReward(Reward reward);
    int getTotalRewardAmount(Long accountNumber);
    List<Reward> getAllRewardsForAccount(Long accountNumber);
}
