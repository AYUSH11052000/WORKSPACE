package com.repo;
import java.util.List;

import com.model.TransactionDetail;

public interface TransactionRepository {
		
		public long addTransaction(TransactionDetail transactionDetail);
		
		public List<TransactionDetail> getAllTransactionDetailsByAccountNumber(Long accountNumber);
}
