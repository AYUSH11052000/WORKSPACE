package com.repo;
import java.util.List;

import com.model.Account;

public interface BankService {

    long transfer(long fromAccount, long toAccount, int amount);

    long debit(int amount, long accountNumber);

    long credit(int amount, long accountNumber);

    void createNewAccount(Account account);

    void deactivateAccount(long accountNumber);

    void activateAccount(long accountNumber);

    List<Account> getAllAccounts();
}
