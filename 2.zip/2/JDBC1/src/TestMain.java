import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.impl.BankServiceImpl;
import com.impl.JDBCTransactionRepositoryImpl;
import com.repo.BankService;

public class TestMain {

	 
		// TODO Auto-generated method stub
		private static BankService bankService;

		static JDBCTransactionRepositoryImpl jdbcTransactionRepository;
	 
		public static void main(String[] args) {
			ApplicationContext context = new AnnotationConfigApplicationContext(Appconfig.class);
 			BankService bankService = context.getBean(BankServiceImpl.class);
			bankService.transfer(51L,53L, 500);
	}
	}

