import java.util.Scanner;
 

public class UserInterface {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
	    //Fill the code here 
	    System.out.println("Enter the sentence");
        String sentence = sc.nextLine().trim();
        if (!sentence.matches("[a-zA-Z ]+")) {
        	System.out.println("Invalid Sentence");
		            return;  
		        }
		        String[] words = sentence.split(" ");
		        int wordCount = words.length;
		        System.out.println("Word Count: " + wordCount);
		        
		        
		        if (wordCount % 2 == 0) {
		    
		            for (int i = wordCount - 1; i >= 0; i--) {
		                System.out.print(words[i] + " ");
		            }
		        } else {
		          
		            for (String word : words) {
		                StringBuilder reversedWord = new StringBuilder(word);
		                System.out.print(reversedWord.reverse().toString() + " ");
		            }
		        }
	 
	     
	    
	}
}
