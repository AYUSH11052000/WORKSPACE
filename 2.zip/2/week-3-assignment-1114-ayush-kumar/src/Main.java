import java.time.LocalDate;
import java.util.*;

public class Main {
    public static void main(String[] args) {
        List<Course> courses = new ArrayList<>(Arrays.asList(
                new Course(1, "Data Structures", "Dr. Smith", "Computer Science", 4, 20),
                new Course(2, "Calculus I", "Dr. Jones", "Mathematics", 3, 30),
                new Course(3, "Physics I", "Dr. Brown", "Physics", 4, 25),
                new Course(4, "Chemistry I", "Dr. Taylor", "Chemistry", 4, 10),
                new Course(5, "Art History", "Dr. Lee", "Art", 3, 15),
                new Course(6, "Microeconomics", "Dr. Miller", "Economics", 3, 0), // Full course
                new Course(7, "Algorithms", "Dr. Smith", "Computer Science", 4, 5),
                new Course(8, "Linear Algebra", "Dr. Johnson", "Mathematics", 3, 20),
                new Course(9, "Astronomy", "Dr. Brown", "Astronomy", 3, 5),
                new Course(10, "Sociology", "Dr. Clark", "Sociology", 3, 12)
        ));

        List<Student> students = new ArrayList<>(Arrays.asList(
                new Student(1, "Alice", "Computer Science", Arrays.asList(courses.get(0), courses.get(1)), LocalDate.of(2021, 1, 15)),
                new Student(2, "Bob", "Mathematics", Arrays.asList(courses.get(1), courses.get(7)), LocalDate.of(2020, 5, 20)),
                new Student(3, "Carol", "Physics", Arrays.asList(courses.get(2), courses.get(8)), LocalDate.of(2022, 3, 10)),
                new Student(4, "David", "Chemistry", Arrays.asList(courses.get(3)), LocalDate.of(2021, 6, 25)),
                new Student(5, "Eve", "Economics", Arrays.asList(courses.get(5)), LocalDate.of(2020, 8, 5)),
                new Student(6, "Frank", "Computer Science", Arrays.asList(courses.get(0), courses.get(6)), LocalDate.of(2021, 9, 30)),
                new Student(7, "Grace", "Art", Arrays.asList(courses.get(4)), LocalDate.of(2019, 2, 18)),
                new Student(8, "Hank", "Mathematics", Arrays.asList(courses.get(1), courses.get(8)), LocalDate.of(2021, 7, 12)),
                new Student(9, "Ivy", "Sociology", Arrays.asList(courses.get(9)), LocalDate.of(2022, 4, 15)),
                new Student(10, "Jack", "Physics", Arrays.asList(courses.get(2)), LocalDate.of(2020, 11, 5))
        ));

         
        System.out.println("Courses in Computer Science Department:");
        System.out.println(StudentCourseUtils.getCoursesByDepartment(courses, "Computer Science"));

         
        System.out.println("\nCourses Grouped by Instructor:");
        System.out.println(StudentCourseUtils.groupCoursesByInstructor(courses));

         
        System.out.println("\nCourse Count by Department:");
        System.out.println(StudentCourseUtils.countCoursesByDepartment(courses));

         
        System.out.println("\nStudents Enrolled in 'Data Structures':");
        System.out.println(StudentCourseUtils.getStudentsInCourse(students, "Data Structures"));

         
        System.out.println("\nMost Recently Enrolled Student:");
        System.out.println(StudentCourseUtils.findMostRecentlyEnrolledStudent(students));

         
        System.out.println("\nStudent with the Most Credit Hours:");
        System.out.println(StudentCourseUtils.findTopCreditStudent(students));

        
        System.out.println("\nAverage Credit Hours by Major:");
        System.out.println(StudentCourseUtils.calculateAverageCreditsByMajor(students));

         
        System.out.println("\nCourses Taken by 'Alice':");
        System.out.println(StudentCourseUtils.getCoursesByStudent(students, "Alice"));

       
        System.out.println("\nCourses Partitioned by Availability:");
        System.out.println(StudentCourseUtils.partitionCoursesByAvailability(courses));

        
        System.out.println("\nTop 3 Students with the Most Courses Enrolled:");
        System.out.println(StudentCourseUtils.getTopCourseEnrolledStudents(students));
    }
}
