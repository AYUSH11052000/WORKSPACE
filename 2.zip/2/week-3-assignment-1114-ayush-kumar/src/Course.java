 import java.util.Objects;

public class Course {
    private int courseId;
    private String courseName;
    private String instructor;
    private String department;
    private int creditHours;
    private int availableSeats;

    // Constructor
    public Course(int courseId, String courseName, String instructor, String department, int creditHours, int availableSeats) {
        this.courseId = courseId;
        this.courseName = courseName;
        this.instructor = instructor;
        this.department = department;
        this.creditHours = creditHours;
        this.availableSeats = availableSeats;
    }

    // Getters and Setters
    public int getCourseId() { return courseId; }
    public void setCourseId(int courseId) { this.courseId = courseId; }

    public String getCourseName() { return courseName; }
    public void setCourseName(String courseName) { this.courseName = courseName; }

    public String getInstructor() { return instructor; }
    public void setInstructor(String instructor) { this.instructor = instructor; }

    public String getDepartment() { return department; }
    public void setDepartment(String department) { this.department = department; }

    public int getCreditHours() { return creditHours; }
    public void setCreditHours(int creditHours) { this.creditHours = creditHours; }

    public int getAvailableSeats() { return availableSeats; }
    public void setAvailableSeats(int availableSeats) { this.availableSeats = availableSeats; }

    // toString method
    @Override
    public String toString() {
        return "Course{" +
                "courseId=" + courseId +
                ", courseName='" + courseName + '\'' +
                ", instructor='" + instructor + '\'' +
                ", department='" + department + '\'' +
                ", creditHours=" + creditHours +
                ", availableSeats=" + availableSeats +
                '}';
    }

    // equals and hashCode for comparison in tasks
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Course course = (Course) o;
        return courseId == course.courseId;
    }

    @Override
    public int hashCode() {
        return Objects.hash(courseId);
    }
}
