 import java.util.*;
import java.util.stream.Collectors;

public class StudentCourseUtils {
    public static List<Course> getCoursesByDepartment(List<Course> courses, String department) {
        return courses.stream()
                .filter(course -> course.getDepartment().equalsIgnoreCase(department))
                .collect(Collectors.toList());
    }
    public static Map<String, List<Course>> groupCoursesByInstructor(List<Course> courses) {
        return courses.stream()
                .collect(Collectors.groupingBy(Course::getInstructor));
    }
    public static Map<String, Long> countCoursesByDepartment(List<Course> courses) {
        return courses.stream()
                .collect(Collectors.groupingBy(Course::getDepartment, Collectors.counting()));
    }
    public static List<Student> getStudentsInCourse(List<Student> students, String courseName) {
        return students.stream()
                .filter(student -> student.getCoursesEnrolled().stream()
                        .anyMatch(course -> course.getCourseName().equalsIgnoreCase(courseName)))
                .collect(Collectors.toList());
    }

    public static Student findMostRecentlyEnrolledStudent(List<Student> students) {
        return students.stream()
                .max(Comparator.comparing(Student::getEnrollmentDate))
                .orElse(null);
    }
 
    public static Student findTopCreditStudent(List<Student> students) {
        return students.stream()
                .max(Comparator.comparingInt(student -> student.getCoursesEnrolled().stream()
                        .mapToInt(Course::getCreditHours)
                        .sum()))
                .orElse(null);
    }
 
    public static Map<String, Double> calculateAverageCreditsByMajor(List<Student> students) {
        return students.stream()
                .collect(Collectors.groupingBy(Student::getMajor,
                        Collectors.averagingInt(student -> student.getCoursesEnrolled().stream()
                                .mapToInt(Course::getCreditHours)
                                .sum())));
    }
    public static List<String> getCoursesByStudent(List<Student> students, String studentName) {
        return students.stream()
                .filter(student -> student.getName().equalsIgnoreCase(studentName))
                .flatMap(student -> student.getCoursesEnrolled().stream())
                .map(Course::getCourseName)
                .distinct()
                .collect(Collectors.toList());
    }

    public static Map<Boolean, List<Course>> partitionCoursesByAvailability(List<Course> courses) {
        return courses.stream()
                .collect(Collectors.partitioningBy(course -> course.getAvailableSeats() > 0));
    }

    public static List<Student> getTopCourseEnrolledStudents(List<Student> students) {
        return students.stream()
                .sorted(Comparator.comparingInt((Student student) -> student.getCoursesEnrolled().size()).reversed())
                .limit(3)
                .collect(Collectors.toList());
    }
}
