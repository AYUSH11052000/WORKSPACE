 import java.time.LocalDate;
import java.util.List;
import java.util.Objects;

public class Student {
    private int studentId;
    private String name;
    private String major;
    private List<Course> coursesEnrolled;
    private LocalDate enrollmentDate;
 
    public Student(int studentId, String name, String major, List<Course> coursesEnrolled, LocalDate enrollmentDate) {
        this.studentId = studentId;
        this.name = name;
        this.major = major;
        this.coursesEnrolled = coursesEnrolled;
        this.enrollmentDate = enrollmentDate;
    }

     
    public int getStudentId() { return studentId; }
    public void setStudentId(int studentId) { this.studentId = studentId; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getMajor() { return major; }
    public void setMajor(String major) { this.major = major; }

    public List<Course> getCoursesEnrolled() { return coursesEnrolled; }
    public void setCoursesEnrolled(List<Course> coursesEnrolled) { this.coursesEnrolled = coursesEnrolled; }

    public LocalDate getEnrollmentDate() { return enrollmentDate; }
    public void setEnrollmentDate(LocalDate enrollmentDate) { this.enrollmentDate = enrollmentDate; }

    // toString method
    @Override
    public String toString() {
        return "Student{" +
                "studentId=" + studentId +
                ", name='" + name + '\'' +
                ", major='" + major + '\'' +
                ", coursesEnrolled=" + coursesEnrolled +
                ", enrollmentDate=" + enrollmentDate +
                '}';
    }

     
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Student student = (Student) o;
        return studentId == student.studentId;
    }

    @Override
    public int hashCode() {
        return Objects.hash(studentId);
    }
}
