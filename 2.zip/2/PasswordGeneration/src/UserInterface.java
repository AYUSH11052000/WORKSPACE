import java.util.Scanner;
 
public class UserInterface {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
       System.out.println("Enter the username ");
       String username = sc.nextLine();
       if (username.length()!=8){
           System.out.println(username +" is an  invalid username");
           return;
       }
       //
       String firstfour = username.substring(0,4);
       char fifthchar =username.charAt(4);
       String courseIdStr = username.substring(5);
       if(!firstfour.matches("[A-Z]{4}")){
           System.out.println(username + "is an  invalid username");
           return;
       }
       if(fifthchar!='@'){
           System.out.println(username + "is an  invalid username");
           return;
       
    }
    int courseId;
    try{
        courseId=Integer.parseInt(courseIdStr);
    }catch(NumberFormatException e){
        System.out.println(username + "is an  invalid username");
           return;
    }
    if(courseId<101 || courseId>115){
        System.out.println(username + "is an  invalid username");
           return;
    }
    int asciiSum =0;
    for(int i=0;i<4;i++){
        asciiSum+= Character.toLowerCase(firstfour.charAt(i));
    }
    String courseIdLastTwo =courseIdStr.substring(1);
    String password = "TECH_" + asciiSum+ courseIdLastTwo;
    System.out.println("Password: " + password);
}
}

