import java.util.Scanner;
public class UserInterface 
{
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		//Fill code here 
		 System.out.println("Enter the Ticket ID:");
		 String ticketId = sc.nextLine();
         System.out.println("Enter the Unlucky Code:");
		 String unluckyCode = sc.nextLine();        
		 int count = ticketId.split(unluckyCode, -1).length - 1;
		 if (count == 0) {
		 System.out.println(ticketId + " is lucky ticket");
        } else if (count < 3) {
         System.out.println(ticketId + " is partially lucky");
         } else {
        System.out.println(ticketId + " is unlucky ticket");
		  }
		    }
		}