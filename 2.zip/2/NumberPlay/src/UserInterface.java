import java.util.Scanner;

public class UserInterface{
    
    public static void main(String[] args){
        
       Scanner sc=new Scanner(System.in);
       
        //Fill the code here
               System.out.println("Enter the number");
               int number = sc.nextInt();
               if (number < 10 || number > 99) {
                   System.out.println("Invalid number");
               } else {
                       if (number > 50) {
                       int tens = number / 10;
                       int ones = number % 10;
                       int difference = tens - ones;
                       System.out.println(difference);
                   }else {
                       int tens = number / 10;
                       int ones = number % 10;
                       int reversed = ones * 10 + tens;
                       int difference = reversed / 10 - reversed % 10;
                       System.out.println(difference);
                   }
               }

          
           }
}