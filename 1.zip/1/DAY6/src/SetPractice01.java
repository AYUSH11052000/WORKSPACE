import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.TreeSet;

public class SetPractice01 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Set numsSet = new HashSet();
		
		numsSet.add(10);
		numsSet.add("Welcome");
		numsSet.add(34.32F);
		numsSet.add("Welcome");
		numsSet.add(34.32);
		numsSet.add("Helloworld");

		System.out.println(numsSet);
		
		
	}

}
