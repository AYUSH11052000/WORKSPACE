import java.util.LinkedList;
import java.util.List;

public class LinkedListPractice01 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		List<Integer> list = new LinkedList<>();
		
		//add elements 
		//remove elements 
		//iterator 
		
		//

	}

}
