import java.util.ArrayList;
import java.util.List;

public class ArrayListPractice {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
				
//		List list = new ArrayList<>();
//
//		list.add(10);
//		list.add("Aryan");
//		list.add("Mahesh");
//		list.add(10);
//		list.add(34.3223F);
//		list.add(54.4343);
//		 
//		list.add(3, 66);
//		
//		System.out.println(list);
//		System.out.println("size :" + list.size());
//
//		list.add(434);
//		System.out.println("size :" + list.size());
		
//		List<Integer> numsList = new ArrayList<>();
//		
//		numsList.add(23);
//		
//		List<String> namesList = new ArrayList<>();
		
		
		

	}

}
