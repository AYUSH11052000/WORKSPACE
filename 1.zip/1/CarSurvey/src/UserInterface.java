
import java.util.List;
import java.util.Scanner;

public class UserInterface {

	public static void main(String[] args) {
		Car CarManager = new Car();
		
		Scanner sc=new Scanner(System.in);
		
		// Code here
		while (true) {
            System.out.println("1.Add car");
            System.out.println("2.Search by name");
            System.out.println("3.Search by count");
            System.out.println("4.Total");
            System.out.println("5.Exit");
            System.out.println("Enter your choice");
            int choice = sc.nextInt();
            sc.nextLine();

            switch (choice) {
                case 1:
                    
                    System.out.println("Enter the car name");
                    String name = sc.nextLine();
                    System.out.println("Enter no of cars sold");
                    int numSold = sc.nextInt();
                    CarManager.addCar(name, numSold);
                    break;

                case 2:
                	if(CarManager.getCarMap().isEmpty()) {
                		System.out.println("The map is empty");
                	}
                	else {
                    System.out.println("Enter the car name");
                    String searchName = sc.nextLine();
                    int soldCount = CarManager.carByName(searchName);
                    if (soldCount == -1) {
                    	System.out.println("Car not found");

                    } else {
                                          
                        System.out.println(soldCount);
                    }
                	}
                    break;

                case 3:           
                    
                    if (CarManager.getCarMap().isEmpty()) {
                       
                       System.out.println("The map is empty");
                        } 
                    else {
                    	System.out.println("Enter the count ");
                    int count = sc.nextInt();
                    List<String> cars = CarManager.carByCount(count);
                    if(cars==null) {
                     System.out.println("No cars found");}
                    else {
                    	for(String x:cars) 
                    		System.out.println(x);
                    	}
                    }
                        
                    
                    break;

                case 4:
                	if(CarManager.getCarMap().isEmpty()) {
                		System.out.println("The map is empty");
                	}
                	else {
                    int totalSold = CarManager.totalCarsSold();
                   
                        System.out.println(totalSold);
                    }
                    break;

                case 5:
                    System.out.println("Thank you for using the application");
                    
                    return;

            }
        }
    }
}