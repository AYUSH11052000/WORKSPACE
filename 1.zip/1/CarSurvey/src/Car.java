import java.util.*;

public class Car {

	Map<String,Integer> carMap=new TreeMap<String,Integer>();

	// Include getter and setter

	public void addCar(String name,int num)
	{
		boolean f=false;
    	Set<String>k=carMap.keySet();
    	for(String x:k) {
    		if(x.equalsIgnoreCase(name)) {
    			f=true;
    		}
    	}
    	if (!f) {
            carMap.put(name, num);
        }
	}
	
	public Map<String, Integer> getCarMap() {
		return carMap;
	}

	public void setCarMap(Map<String, Integer> carMap) {
		this.carMap = carMap;
	}

	public int carByName(String name)
	{
		// Code here
		if(carMap.containsKey(name)){
			return carMap.get(name);
		}
		else
			return -1;
		
	}
	
	public List<String> carByCount(int count)
	{
		// Code here
		List<String> result = new ArrayList<>();
		if(count>0) {
		for (Map.Entry<String,Integer>entry :carMap.entrySet()) {
		
			if (entry.getValue() >= count) {
                result.add(entry.getKey());
            }
        }
	}
		if(result.isEmpty())
			return null;
		else
			return result;
	}
	public int totalCarsSold()
	{
//		// Code here
//		if(carMap.isEmpty()) {
//			return-2 ;
//		}
		int total =0;
		for(int value : carMap.values() ) {
			total+=value;
		}
		return total ;
	}
	
}
