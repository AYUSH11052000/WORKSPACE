
public class EmployeeService {
	private EmployeeDAO empDao;
	public EmployeeService() {
		this.empDao = new EmployeeDAO();
	}
	public void addEmployee (int id , String name , String age, String panCard) {
		try {
			int a = Integer.parseInt(age);
			Employee employee = new Employee(id,age,name,panCard);
		}
		
	}

}
