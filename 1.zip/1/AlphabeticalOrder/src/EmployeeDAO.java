import java.util.HashMap;
import java.util.Map;

public class EmployeeDAO {
	private Map<Integer,Employee>employee = new HashMap<>();
	public void addEmployee(Employee employee) {
		employee.put(employee.getId(),employee);
	}
	public Employee getEmployeeById(int id) throws EmployeeNotFoundException {
		Employee employee = employee.get(Id);
		if(employee ==null)
			throw new EmployeeNotFoundException("Employee not found with the given id");
		return employee;
	}
	
}
