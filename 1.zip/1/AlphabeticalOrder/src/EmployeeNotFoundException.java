
public class EmployeeNotFoundException  extends Exception{
	

}
