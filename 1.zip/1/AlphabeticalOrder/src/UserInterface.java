import java.util.Arrays;
import java.util.Scanner;
public class UserInterface
{
	public static void main(String[] args)
	{
		  
		         Scanner sc = new Scanner(System.in);
		         System.out.println("Enter the sentence");
		         String input = sc.nextLine();
		         if (input.matches("[a-z ]+")) {
		             String[] words = input.split(" ");
		             StringBuilder result = new StringBuilder();
		             for (String word : words) {
		                 char[] letters = word.toCharArray();
		                 java.util.Arrays.sort(letters);
		                 result.append(new String(letters)).append(" ");
		             }
		             System.out.println(result.toString().trim());
		         } else {
		             System.out.println(input + " is an invalid input");
		         }
		     }
		 }

	         

