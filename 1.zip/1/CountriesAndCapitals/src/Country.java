import java.util.Map;
import java.util.Set;
import java.util.HashMap;

public class Country {
    
    private Map<String,String> countryMap=new HashMap<String,String>();

        // Write code for getter and setter

    public void add(String cname,String capname)
    {
	    // Code here
    	boolean f=false;
    	Set<String>k=countryMap.keySet();
    	for(String x:k) {
    		if(x.equalsIgnoreCase(cname)) {
    			f=true;
    		}
    	}
    	if (!f) {
            countryMap.put(cname, capname);
        }
    }
    public Map<String, String> getCountryMap() {
		return countryMap;
	}

	public void setCountryMap(Map<String, String> countryMap) {
		this.countryMap = countryMap;
	}

	public String search(String cname)
    {
	    // Code  here
		
		if (!countryMap.containsKey(cname)) {
			return null ;
		}    
	    return countryMap.get(cname);
    }
}
