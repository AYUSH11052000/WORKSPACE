import java.util.Arrays;
import java.util.Set;
import java.util.TreeSet;

public class TreeSetPractice01 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

//		Set<Integer> numsSet = new TreeSet<>();
//		
//		numsSet.addAll(Arrays.asList(23,21,46,2,65,44,66,55,34,43));
//		
//		System.out.println(numsSet);
		
//		Set<String> namesSet = new TreeSet<>();
//		
//		namesSet.addAll(Arrays.asList("Atharva", "Harshad", "Vedant", "Yash", "Satyam", "Atharva"));
//		
//		System.out.println(namesSet);
		
	}

}
