import java.util.function.Predicate;

public class TestFunctionalInterface01 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	int[]array = {34,54,3,2,22,55,57,23,7,3,67,3,65,33,76};
	Predicate<Integer>predicate1 =new Predicate<Integer>() {

		@Override
		public boolean test(Integer t) {
			// TODO Auto-generated method stub
			return false;
		}
		
	};
	show(array,predicate1);

	}
	public static void show(int[]array,Predicate<Integer>predicate) {
		for(int value:array) {
			if(predicate.test(value))
				System.out.println(value);
		}
		
	}

}
