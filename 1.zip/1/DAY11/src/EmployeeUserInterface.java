
public class EmployeeUserInterface {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//1.Add Employee
			//input id, age, name and pancard
		//2.Fetch Employee
			//input id
		//3. Exit

	}

}
