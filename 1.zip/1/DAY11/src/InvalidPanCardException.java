
public class InvalidPanCardException extends Exception {

	
	public InvalidPanCardException(String message) {
		super(message);
	}
}
