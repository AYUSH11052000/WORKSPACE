
public class InvalidAgeExpcetion extends Exception {

	
	public InvalidAgeExpcetion(String message) {
		super(message);
	}
}
