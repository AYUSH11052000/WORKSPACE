public enum transactiontype {
    CREDIT,
    DEBIT;
}
