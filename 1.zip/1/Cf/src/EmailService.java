public class EmailService {

    public void sendMail(String toEmail, String fromEmail, String subject, String body) {
        // Mock email sending logic (can be replaced with actual SMTP or external service like SendGrid)
        System.out.println("Sending email to: " + toEmail);
        System.out.println("From: " + fromEmail);
        System.out.println(subject);
        System.out.println(body);
    }
}
