import java.util.List;

public interface RewardRepository {
    void addReward(Reward reward);
    int getTotalRewardAmount(Long accountNumber);
    List<Reward> getAllRewardsForAccount(Long accountNumber);
}
