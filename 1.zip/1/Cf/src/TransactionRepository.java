import java.util.List;

public interface TransactionRepository {
		
		public long addTransaction(TransactionDetail transactionDetail);
		
		public List<TransactionDetail> getAllTransactionDetailsByAccountNumber(Long accountNumber);
}
