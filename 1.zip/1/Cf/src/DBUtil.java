import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBUtil {
	private final static String dbUrl="jdbc:postgresql://localhost:5432/bank";
	private final static String username="postgres";
	private final static String pass="root";
	
	public static Connection getConnection() throws SQLException{
		return DriverManager.getConnection(dbUrl,username,pass);
	}
}