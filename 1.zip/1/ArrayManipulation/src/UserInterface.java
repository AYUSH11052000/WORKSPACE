import java.util.InputMismatchException;
import java.util.Scanner;

public class UserInterface
{
	public String getDuplicateElement(){
        Scanner sc = new Scanner(System.in);
        try 
        {
        System.out.println("Enter the size of an array");
        int arraysize = sc.nextInt();
        if(arraysize<0) {
        	throw new NegativeArraySizeException ();
        }
        int []array = new int [arraysize];
        System.out.println("Enter the array elements");
        for (int i = 0; i < arraysize; i++) {
        	 array[i] = sc.nextInt();
        }
      System.out.println("Enter the position of the element to be replicated");
      int position =sc.nextInt();
      if (position < 0 || position >= arraysize) {
    	  throw new ArrayIndexOutOfBoundsException ();
      }
        	 StringBuilder result  = new StringBuilder();
        	 for(int i = 0;i<arraysize;i++) {
        		 result.append(array[i]+" ");
        	 }
        	 result.append(array[position]);
        	 
         return "The array elements are " + result.toString();
        
        }catch (ArrayIndexOutOfBoundsException e) {
            return "Array index is out of range";
        } catch (InputMismatchException e) {
            return "Input was not in the correct format";
        } catch (NegativeArraySizeException e) {
            return "Array size should be positive";
        }
           
        }
        
	
	public static void main(String[] args)
    {
        // Fill the code
		 UserInterface ui = new UserInterface();
	        String result = ui.getDuplicateElement();
	        System.out.println(result);
    }
}