
public class D5STRINGMANIPULATION {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		String str1 = "Rohit";		//using string literal 
			
		String str3 = "Welcome";
		
		str3 = "New String";
	
		String str4 = "helloworld";
		
		String str2 = new String("Rohan");		//using constructor 
		
		

//		if(str1.equalsIgnoreCase(str2))
//			System.out.println("Both are equal strings");
//		else 
//			System.out.println("not equal");
		
		System.out.println( str1.compareTo(str2) );
		
//		int index = str1.indexOf("i");
//		System.out.println(index);
//		
		
//		char ch = str1.charAt(78);
//		System.out.println(ch);
		
		
		
	}

}
	