import java.util.List;
import java.util.function.Predicate;
import java.util.stream.Stream;
import java.util.*;

public class StreamAPIPractice01 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<Person>personList = PersonList.createPersonList();
		 long count = personList
				 .stream()
				 .filter(person-> person.getEmail().endsWith("gmail.com"))
		         .count();	
		 System.out.println(count);

	}

}
